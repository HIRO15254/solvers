#!/bin/bash
set -euxo pipefail
export CARGO_HOME=/opt/r1/cargo
export RUSTUP_HOME=/opt/r1/rustup
export RUSTUP_TOOLCHAIN=1.97.0
export PATH=/opt/r1/cargo/bin:$PATH
export CARGO_BUILD_JOBS=4
mkdir /opt/r1/phase-baseline /opt/r1/phase-candidate
tar --touch -xzf /opt/r1/baseline-source.tar.gz -C /opt/r1/phase-baseline
tar --touch -xzf /opt/r1/candidate-v3-source.tar.gz -C /opt/r1/phase-candidate
python3 /opt/r1/phase-tools/apply_instrumentation.py --source baseline9632 --root /opt/r1/phase-baseline
python3 /opt/r1/phase-tools/apply_instrumentation.py --source candidate03 --root /opt/r1/phase-candidate
# Reuse only reproducible Cargo build outputs; immutable comparison binaries
# remain in their original target directories, never overwritten by this build.
cp -a /opt/r1/target/baseline /opt/r1/target/phase-baseline
cp -a /opt/r1/target/candidate-v3 /opt/r1/target/phase-candidate
for version in baseline candidate; do
    cd /opt/r1/phase-$version
    export CARGO_TARGET_DIR=/opt/r1/target/phase-$version
    {
        rustc -Vv
        cargo -V
        sha256sum Cargo.lock .cargo/config.toml r1-phase-source-manifest.json
        /usr/bin/time -v cargo build --locked --release -p cli --bin solvers
        sha256sum /opt/r1/target/phase-$version/release/solvers
        date -u --iso-8601=seconds
    } > /opt/r1/phase-$version-build.log 2>&1
done
date -u --iso-8601=seconds > /opt/r1/build-phases-complete
