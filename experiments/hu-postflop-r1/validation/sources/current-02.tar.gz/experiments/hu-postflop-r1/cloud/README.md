# R1 Spot実験の費用と回収

利用者の累計20 USD許可から、初回は5 USDを予約する。[台帳](budget.json)は請求額と予約額を区別する。
単一e2-highmem-8（8 vCPU / 64 GiB）、100 GiB pd-balanced、最大3時間。
実験環境の構築と通常検証、その後の同一CPUでの基準／変更版測定に使う。

2026-09-25に確認した一次料金は、[e2-highmem-8通常料金](https://cloud.google.com/products/compute/pricing/general-purpose)
0.36159864 USD/h、[balanced disk](https://cloud.google.com/compute/disks-image-pricing)約0.000136986 USD/GiB/h、
[Spot IPv4](https://cloud.google.com/vpc/pricing-announce-external-ips)0.0025 USD/h。
Spotの変動額そのものは未取得なので、CPU/RAMは通常料金を切り上げた0.37 USD/hで予約する。
ダウンロードは最大2 GiB、転送予備0.30 USD/GiB、削除遅延・税・料金差等の予備を含め5 USD。
請求未反映の予約を解放して次のVMを増設しない。

[launch.ps1](launch.ps1)は起動前に予約総額を検査し、一意の試行記録を書いてから作成する。
[絶対終了時刻](https://docs.cloud.google.com/compute/docs/instances/limit-vm-runtime)にDELETE、
boot diskはauto-delete、Spot回収時もDELETE。停止からの自動再起動はしない。
固定IP、snapshot、外部bucket、サービスアカウントを作らない。
接続は既存gcloud認証を使い、[bootstrap](bootstrap.sh)はRust/toolchainと標準build依存を導入する。

削除前に小さいログ・manifest・結果を回収しSHA-256を照合する。
大型binaryや成果物は回収前にsizeを確認し、転送枠に含める。
終了時に記録したinstance ID/nameとboot diskの消失を確認する。自分のlabel/name以外は削除しない。
Spot回収で消失した未回収runは成功とせず、中断として残す。
Python supervisorは各コマンドのtimeout/resource制御に使い、Linuxではsystemd scopeのcgroupで子孫も囲む。

この台帳はR1実験費用の証拠であり、作業状態の管理先はLinear。

## 転送許可

最初のsource転送は自動承認レビューが非公開repositoryの転送許可不足として拒否した。
利用者は続けて「ファイルの転送を全面的に許可します。理由はこれらのアプリケーションは
最終的にオープンソースとなるためです」と明示した。この許可に基づき同projectの実験VMへ転送する。
基準build sourceは9632d8bのCargo設定とcrates、871630 byte、
SHA-256 `fdd8c1c014a94c70b56efbd79a36c18f6f1634c20aaf9062660ee3a6133a0197`。
VM側でも同hashを照合した。基準sourceの完全内容は当該Git commitから復元可能。
