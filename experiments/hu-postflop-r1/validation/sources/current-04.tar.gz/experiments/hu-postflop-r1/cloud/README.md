# R1 Spot実験の費用と回収

利用者の累計20 USD許可から、初回は5 USDを予約する。[台帳](budget.json)は請求額と予約額を区別する。
単一e2-highmem-8（8 vCPU / 64 GiB）、100 GiB pd-balanced、最大3時間。
実験環境の構築と通常検証、その後の同一CPUでの基準／変更版測定に使う。

2026-09-25に確認した一次料金は、[e2-highmem-8通常料金](https://cloud.google.com/products/compute/pricing/general-purpose)
0.36159864 USD/h、[balanced disk](https://cloud.google.com/compute/disks-image-pricing)約0.000136986 USD/GiB/h、
[Spot IPv4](https://cloud.google.com/vpc/pricing-announce-external-ips)0.0025 USD/h。
Spotの変動額そのものは未取得なので、CPU/RAMは通常料金を切り上げた0.37 USD/hで予約する。
ダウンロードは最大2 GiB、転送予備0.30 USD/GiB、削除遅延・税・料金差等の予備を含め5 USD。
請求未反映の予約を解放して次のVMを増設しない。

[launch.ps1](launch.ps1)は起動前に予約総額を検査し、一意の試行記録を書いてから作成する。
[絶対終了時刻](https://docs.cloud.google.com/compute/docs/instances/limit-vm-runtime)にDELETE、
boot diskはauto-delete、Spot回収時もDELETE。停止からの自動再起動はしない。
固定IP、snapshot、外部bucket、サービスアカウントを作らない。
接続は既存gcloud認証を使い、[bootstrap](bootstrap.sh)はRust/toolchainと標準build依存を導入する。

削除前に小さいログ・manifest・結果を回収しSHA-256を照合する。
大型binaryや成果物は回収前にsizeを確認し、転送枠に含める。
終了時に記録したinstance ID/nameとboot diskの消失を確認する。自分のlabel/name以外は削除しない。
Spot回収で消失した未回収runは成功とせず、中断として残す。
Python supervisorは各コマンドのtimeout/resource制御に使い、Linuxではsystemd scopeのcgroupで子孫も囲む。

この台帳はR1実験費用の証拠であり、作業状態の管理先はLinear。

## 転送許可

最初のsource転送は自動承認レビューが非公開repositoryの転送許可不足として拒否した。
利用者は続けて「ファイルの転送を全面的に許可します。理由はこれらのアプリケーションは
最終的にオープンソースとなるためです」と明示した。この許可に基づき同projectの実験VMへ転送する。
基準build sourceは9632d8bのCargo設定とcrates、871630 byte、
SHA-256 `fdd8c1c014a94c70b56efbd79a36c18f6f1634c20aaf9062660ee3a6133a0197`。
VM側でも同hashを照合した。基準sourceの完全内容は当該Git commitから復元可能。

## 段階ごとの証拠回収

[collect-evidence.py](collect-evidence.py) は明示した file/directory だけを読み、
`tar.gz`、同内容の retention manifest、SHA-256 sidecar を出力する。Python 3.11+ の標準ライブラリだけを使う。
存在しないroot・重複root・既存output・symlinkのrootはerrorにする。remote操作やVM削除は行わない。
archiveとsidecarの**合計**を `--max-bytes` 以下（既定2 GiB、これを超える指定は拒否）に制限する。
繰り返し回収する場合、各回の上限を累計ダウンロード枠の残額へ収める。既定2 GiBを各回の追加枠と扱わない。

Spot回収で未転送データが失われるため、validation/build/pilot/pairedの完了ごとに小さいbundleを回収する。
選んだrootのwriterは停止済みであること。進行中の次stageのrootは選ばない。
入力のhash中・packing中に変更を検出した場合はerrorとし、不完全なbundleを公開しない。
以下のpathは実際に存在する完了stageだけを選ぶ例であり、欠測stageのrootをそのまま渡さない。

```sh
python3 /opt/r1/current/experiments/hu-postflop-r1/cloud/collect-evidence.py \
  --out /opt/r1/evidence-validation-03.tar.gz \
  --max-bytes 536870912 \
  --root validation=/opt/r1/validation-03 \
  --root baseline-build=/opt/r1/baseline-build-pinned.log \
  --root baseline-source=/opt/r1/baseline-source.tar.gz \
  --git-source baseline-source=9632d8b \
  --root baseline-binary=/opt/r1/target/baseline/release/solvers

python3 /opt/r1/current/experiments/hu-postflop-r1/cloud/collect-evidence.py \
  --out /opt/r1/evidence-pilot-03.tar.gz \
  --max-bytes 536870912 \
  --root pilot=/opt/r1/current/runs/r1-pilot
```

比較完了後は `--root paired=/opt/r1/current/runs/r1-paired`、必要なら固定planのrootを追加する。
変更版source archive、binary、build logも各々存在するpathを明示する。
directory内の `target/.cache/.git/cargo/rustup` は走査・収容しない。
binaryは例のように **fileそのもの** をrootにすればtarget配下でも収容できる。

8 MiB以下のrecord/config/logを優先し、その後は残るfileを小さい順に収容する。
実runの `.sol`、checkpoint、export stdout/stderr、resource JSONLも同じ枠内で選ぶ。
全対象regular fileについて元の絶対path、相対path、bytes、SHA-256、収容有無をmanifestに残す。
容量で省いたfileは `removed-with-VM`、`--git-source LABEL=REF` を明示したsource rootだけは
`source-contents-reproducible-from-git` とする。これは**内容**の復元可能性であり、archiveの元bytesが
戻せるという主張ではない。binary・run成果物へGit復元指定を流用しない。
symlinkは辿らず、link先文字列のhashと欠測理由を記録する。除外cacheは内容をinventoryしない。

archive内は短い `files/00000000` の名前を使い、manifestの `archive_member` で元pathへ対応付ける。
収容fileの可用性は `in-evidence-bundle-pending-download-verification` とする。
collector終了時のJSONにarchive/manifest hashと合計bytesを出す。3出力をローカルへ回収してhashを
照合するまで、VM上のbundleだけを長期保持済み証拠と扱わない。VM削除後もmanifestと照合記録を残す。

`pack-source.py`は選定ファイルと内容hashのmanifest、時刻を固定したsource archiveを作る。
既存Cargo targetを再利用する場合、抽出は必ず `tar --touch -xzf ...` とする。
固定した過去mtimeで上書きするとCargoが既存binaryを再利用する場合があるため、
sourceの内容hash一致だけで新しいコードの検証成功とはしない。
