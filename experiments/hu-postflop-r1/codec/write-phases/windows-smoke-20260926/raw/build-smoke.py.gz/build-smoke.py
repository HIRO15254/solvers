from pathlib import Path
import datetime as dt, importlib.util, json, os, subprocess, sys
repo=Path(r'C:\Users\PC_User\.codex\worktrees\ce71\solvers')
root=Path(r'E:\codex-work\solvers\r1-writer-smoke-20260926')
source=root/'candidate-instrumented'
target=Path(r'E:\codex-work\solvers\target\r1-writer-smoke-20260926')
assert not target.exists(), 'fresh target required'
assert json.loads((repo/'runs/r1-workspace-warm-4threads-20260926/supervisor.json').read_bytes())['state']=='completed'
spec=importlib.util.spec_from_file_location('supervisor',repo/'tools/run_supervised.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
source_manifest=source/'r1-write-phase-source.json'
pins=json.loads(source_manifest.read_bytes())['after']
def sources():
    result={name:{k:m.identity(source/name)[k] for k in ('bytes','sha256')} for name in pins}
    assert result==pins, 'source changed'
    return result
sources()
copy_record=json.loads((root/'copy.json').read_bytes())
assert copy_record['supervisor_exit_code']==0 and copy_record['cleanup_complete']
resources=m.WindowsAPI().memory()
assert resources['available_bytes']>=4*1024**3 and resources['commit_available_bytes']>=1536*1024**2, resources
target.mkdir(parents=True)
toolchain=Path(r'C:\Users\PC_User\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin')
environment={'CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(target),'CARGO_NET_OFFLINE':'true','RUSTFLAGS':'','RUSTC':str(toolchain/'rustc.exe')}
os.environ.update(environment)
argv=[str(toolchain/'cargo.exe'),'build','--locked','--offline','-p','formats','--example','sol_codec_bench','--target-dir',str(target)]
plan={'schema':'r1.writer-smoke-build-plan/v1','created_at':m.utc_now(),'scope':'Fresh Windows debug build of candidate instrumented example; not the release Linux campaign','cwd':str(source),'argv':argv,'environment':environment,'resources_before':resources,'source_manifest':m.identity(source_manifest),'source_files':sources(),'toolchain':{name:{'identity':m.identity(toolchain/(name+'.exe')),'version':subprocess.check_output([str(toolchain/(name+'.exe')),flag],timeout=10,text=True)} for name,flag in [('cargo','-V'),('rustc','-Vv')]},'limits':{'timeout_seconds':600,'memory_limit_bytes':805306368,'min_free_memory_bytes':3221225472,'disk_reserve_bytes':4294967296},'r1_acceptance':None}
plan_path=root/'build-plan.json'; m.atomic_json(plan_path,plan,initial=True)
args=['--record',str(root/'build.json'),'--cwd',str(source),'--timeout-seconds','600','--memory-limit-bytes','805306368','--min-free-memory-bytes','3221225472','--disk-reserve-bytes','4294967296','--disk-path',str(target),'--poll-seconds','0.1']
for path in [plan_path,source_manifest,Path(__file__),toolchain/'rustc.exe',*[source/name for name in pins]]:
    args+=['--identity-file',str(path)]
code=m.main(args+['--']+argv)
record=json.loads((root/'build.json').read_bytes())
result={'schema':'r1.writer-smoke-build-result/v1','supervisor_exit':code,'source_files_after':sources(),'source_unchanged':True,'completed_at':m.utc_now(),'r1_acceptance':None}
if code==0:
    assert record['cleanup_complete'] and record['identity_unchanged'] and not record['errors']
    result['binary']=m.identity(target/'debug/examples/sol_codec_bench.exe')
m.atomic_json(root/'build-result.json',result,initial=True)
print(json.dumps({k:v for k,v in result.items() if k!='source_files_after'}))
sys.exit(code)
