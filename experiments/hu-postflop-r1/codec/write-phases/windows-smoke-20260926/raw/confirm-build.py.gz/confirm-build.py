from pathlib import Path
import importlib.util,json,os,sys
repo=Path(r'C:\Users\PC_User\.codex\worktrees\ce71\solvers'); root=Path(r'E:\codex-work\solvers\r1-writer-smoke-20260926')
spec=importlib.util.spec_from_file_location('supervisor',repo/'tools/run_supervised.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
prior=json.loads((root/'build.json').read_bytes()); build=json.loads((root/'build-plan.json').read_bytes())
assert prior['child_exit_code']==0 and prior['stop_reason']=='descendants_after_root_exit' and prior['cleanup_complete'] and prior['identity_unchanged']
source=Path(build['cwd']);pins=build['source_files']
def check_source():
    for name,expected in pins.items():
        actual=m.identity(source/name); assert all(actual[k]==expected[k] for k in ('bytes','sha256')),name
check_source()
binary=Path(build['environment']['CARGO_TARGET_DIR'])/'debug/examples/sol_codec_bench.exe'
before=m.identity(binary)
plan={'schema':'r1.writer-smoke-build-confirmation-plan/v1','created_at':m.utc_now(),'reason':'Initial compiler exited zero, but lingering Job descendants failed cleanup supervision; preserve that failed record and run the same command once against the completed cache to verify clean Cargo completion and bind the unchanged binary. This is not a fresh release build.','prior_supervisor':m.identity(root/'build.json'),'prior_plan':m.identity(root/'build-plan.json'),'binary_before':before,'argv':build['argv'],'cwd':build['cwd'],'environment':build['environment'],'source_files':pins,'r1_acceptance':None}
plan_path=root/'confirm-plan.json';m.atomic_json(plan_path,plan,initial=True)
os.environ.update(build['environment'])
args=['--record',str(root/'confirm.json'),'--cwd',str(source),'--timeout-seconds','30','--memory-limit-bytes','805306368','--min-free-memory-bytes','3221225472','--disk-reserve-bytes','4294967296','--disk-path',str(root),'--poll-seconds','0.1']
for path in [Path(__file__),plan_path,Path(build['environment']['RUSTC']),binary,*[source/name for name in pins]]:args+=['--identity-file',str(path)]
code=m.main(args+['--']+build['argv']);check_source()
after=m.identity(binary);assert after==before
result={'schema':'r1.writer-smoke-build-confirmation-result/v1','completed_at':m.utc_now(),'supervisor_exit':code,'source_unchanged':True,'binary':after,'binary_unchanged':True,'r1_acceptance':None}
m.atomic_json(root/'confirm-result.json',result,initial=True);print(json.dumps(result));sys.exit(code)
