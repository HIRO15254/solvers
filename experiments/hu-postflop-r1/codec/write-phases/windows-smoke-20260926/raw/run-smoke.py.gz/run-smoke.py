from pathlib import Path
import importlib.util,json,os,sys
repo=Path(r'C:\Users\PC_User\.codex\worktrees\ce71\solvers');root=Path(r'E:\codex-work\solvers\r1-writer-smoke-20260926')
spec=importlib.util.spec_from_file_location('supervisor',repo/'tools/run_supervised.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
confirmed=json.loads((root/'confirm-result.json').read_bytes());assert confirmed['supervisor_exit']==0 and confirmed['source_unchanged'] and confirmed['binary_unchanged']
source=root/'candidate-instrumented';source_manifest=source/'r1-write-phase-source.json';pins=json.loads(source_manifest.read_bytes())['after']
binary=Path(confirmed['binary']['path']);assert m.identity(binary)==confirmed['binary']
input_path=root/'flop.sol';validator=repo/'experiments/hu-postflop-r1/codec/write-phases/validate.py'
for role in ['off','on']:(root/role).mkdir()
stages=[{'role':role,'argv':[str(binary),str(input_path),'stream-write','1',str(root/role/'output')],'phase_environment':None if role=='off' else str(root/role/'phase.json'),'timeout_seconds':60} for role in ['off','on']]
stages.append({'role':'validate','argv':[sys.executable,str(validator),'--phase',str(root/'on/phase.json'),'--sample',str(root/'on/output/result.json'),'--rewritten',str(root/'on/output/rewritten.sol')],'phase_environment':None,'timeout_seconds':15})
plan={'schema':'r1.writer-windows-smoke-plan/v1','created_at':m.utc_now(),'scope':'One candidate OFF/ON pair in Windows debug mode. Confirms instrumentation runtime and byte preservation only, without performance, calibration or Linux campaign acceptance.','source_manifest':m.identity(source_manifest),'source_files':pins,'build_confirmation':m.identity(root/'confirm.json'),'binary':m.identity(binary),'input':m.identity(input_path),'validator':m.identity(validator),'stages':stages,'environment':{'RAYON_NUM_THREADS':'1'},'limits':{'memory_limit_bytes':536870912,'min_free_memory_bytes':3221225472,'disk_reserve_bytes':4294967296,'grace_seconds':5,'kill_wait_seconds':5,'poll_seconds':0.05},'r1_acceptance':None}
plan_path=root/'smoke-plan.json';m.atomic_json(plan_path,plan,initial=True)
os.environ['RAYON_NUM_THREADS']='1'
result={'schema':'r1.writer-windows-smoke-result/v1','plan':m.identity(plan_path),'stages':[],'r1_acceptance':None}
def source_check():
    for name,expected in pins.items():
        actual=m.identity(source/name);assert all(actual[k]==expected[k] for k in ('bytes','sha256')),name
for stage in stages:
    source_check()
    os.environ.pop('R1_SOL_WRITE_PHASE_OUTPUT',None)
    if stage['phase_environment'] is not None:os.environ['R1_SOL_WRITE_PHASE_OUTPUT']=stage['phase_environment']
    record=root/(stage['role']+'.json')
    args=['--record',str(record),'--cwd',str(root),'--timeout-seconds',str(stage['timeout_seconds']),'--memory-limit-bytes','536870912','--min-free-memory-bytes','3221225472','--disk-reserve-bytes','4294967296','--disk-path',str(root),'--grace-seconds','5','--kill-wait-seconds','5','--poll-seconds','0.05']
    for path in [Path(__file__),plan_path,source_manifest,binary,input_path,validator]:args+=['--identity-file',str(path)]
    code=m.main(args+['--']+stage['argv']);source_check()
    current=json.loads(record.read_bytes())
    result['stages'].append({'role':stage['role'],'supervisor_exit':code,'record':m.identity(record),'source_unchanged':True})
    if code!=0 or not current['cleanup_complete'] or not current['identity_unchanged'] or current['errors']:
        result['status']='failed';m.atomic_json(root/'smoke-result.json',result,initial=True);print(json.dumps(result));sys.exit(1)
for role in ['off','on']:assert (root/role/'output/rewritten.sol').read_bytes()==input_path.read_bytes()
for name in ['canonical.bin','root-canonical.bin']:
    assert (root/'off/output'/name).read_bytes()==(root/'on/output'/name).read_bytes(),name
result.update(status='runtime_smoke_verified',completed_at=m.utc_now(),rewritten_sol_equal_to_input=True,canonical_and_root_equal=True,source_unchanged=True)
result['artifacts']={str(path.relative_to(root)):m.identity(path) for role in ['off','on'] for path in (root/role).rglob('*') if path.is_file()}
m.atomic_json(root/'smoke-result.json',result,initial=True)
print(json.dumps({k:v for k,v in result.items() if k!='artifacts'}))
