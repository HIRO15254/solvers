from pathlib import Path
import importlib.util,json,os,shutil,sys,time,statistics
repo=Path(r'C:\Users\PC_User\.codex\worktrees\ce71\solvers'); campaign=Path(r'E:\codex-work\solvers\r1-context-reuse-20260926'); root=campaign/'fresh'
root.mkdir();[(root/p).mkdir() for p in ['records','binaries','samples']]
spec=importlib.util.spec_from_file_location('supervisor',repo/'tools/run_supervised.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
manifest_path=campaign/'source/r1-context-reuse-source.json';manifest=json.loads(manifest_path.read_bytes())
sources={'baseline':Path(manifest['source_path']),'candidate':campaign/'source'};pins={'baseline':manifest['before'],'candidate':manifest['after']}
targets={role:Path(r'E:\codex-work\solvers\target')/('r1-context-fresh-'+role+'-20260926') for role in sources}
assert all(not p.exists() for p in targets.values());[p.mkdir() for p in targets.values()]
toolchain=Path(r'C:\Users\PC_User\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin');cargo=str(toolchain/'cargo.exe')
common_env={'CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true','RUSTFLAGS':'','RUSTC':str(toolchain/'rustc.exe'),'RAYON_NUM_THREADS':'1','RUST_TEST_THREADS':'1'}
os.environ.update(common_env);os.environ.pop('R1_SOL_WRITE_PHASE_OUTPUT',None)
selection=json.loads((repo/'experiments/hu-postflop-r1/codec/inputs.json').read_bytes())
inputs={case:campaign/'inputs'/(case+'.sol') for case in selection['cases']}
for case,path in inputs.items():
    actual=m.identity(path);assert all(actual[k]==selection['cases'][case][k] for k in ('bytes','sha256'))
stages=[]
for role in sources:
    argv=[cargo,'build','--locked','--offline','-p','formats','--example','sol_codec_bench','--target-dir',str(targets[role])]
    stages.append({'label':'build-'+role,'role':role,'kind':'build','cwd':str(sources[role]),'argv':argv,'timeout':240})
stages.append({'label':'formats-tests','role':'candidate','kind':'test','cwd':str(sources['candidate']),'argv':[cargo,'test','--locked','--offline','-p','formats','--target-dir',str(targets['candidate']),'--','--test-threads=1'],'timeout':180})
for case in inputs:
    for repeat in range(1,4):
        for role in (['baseline','candidate'] if repeat%2 else ['candidate','baseline']):
            label=f'{case}-{repeat}-{role}'
            stages.append({'label':label,'role':role,'kind':'sample','case':case,'repeat':repeat,'cwd':str(root),'argv':[str(root/'binaries'/(role+'.exe')),str(inputs[case]),'stream-write','1',str(root/'samples'/label)],'timeout':60})
def check_sources():
    for role in sources:
        for name,expected in pins[role].items():
            actual=m.identity(sources[role]/name);assert all(actual[k]==expected[k] for k in ('bytes','sha256')),(role,name)
check_sources();resources=m.WindowsAPI().memory();assert resources['available_bytes']>=4*1024**3 and resources['commit_available_bytes']>=1536*1024**2
plan={'schema':'r1.context-reuse-fresh-diagnostic-plan/v1','created_at':m.utc_now(),'scope':'Fresh independent Windows debug targets; three alternating pairs per fixed River/Turn/Flop. Local diagnostic, not dedicated-host performance certification or old Linux regression attribution.','replaces_invalid_attempt':m.identity(campaign/'diagnostic-result.json'),'source_manifest':m.identity(manifest_path),'source_files':pins,'sources':{k:str(v) for k,v in sources.items()},'targets':{k:str(v) for k,v in targets.items()},'common_environment':common_env,'fresh_targets_before':True,'resources_before':resources,'inputs':{case:m.identity(path) for case,path in inputs.items()},'stages':stages,'overall_timeout_seconds':1500,'build_memory_bytes':805306368,'sample_memory_bytes':536870912,'min_free_memory_bytes':3221225472,'disk_reserve_bytes':4294967296,'cleanup_recovery':'For build/test only: if Cargo exit 0, source/identity unchanged, cleanup complete, and sole failure is descendants_after_root_exit with AttachConsole signal error, preserve failure and run same command exactly once with 30s timeout against its OWN target. Require unchanged example binary and normal supervisor 0. No recovery for compile/test/memory/timeout failures.','r1_acceptance':None}
plan_path=root/'plan.json';m.atomic_json(plan_path,plan,initial=True)
result={'schema':'r1.context-reuse-fresh-diagnostic-result/v1','plan':m.identity(plan_path),'status':'running','stages':[],'binaries':{},'r1_acceptance':None};started=time.monotonic()
def failure(label):
    result.update(status='failed',first_failure=label,ended_at=m.utc_now());m.atomic_json(root/'result.json',result,initial=True);print(json.dumps({'status':'failed','stage':label}),flush=True);sys.exit(1)
def run_stage(stage,suffix='',timeout=None):
    assert time.monotonic()-started+(timeout or stage['timeout'])+15<1500,'overall deadline'
    check_sources();os.environ['CARGO_TARGET_DIR']=str(targets[stage['role']])
    record=root/'records'/(stage['label']+suffix+'.json')
    args=['--record',str(record),'--cwd',stage['cwd'],'--timeout-seconds',str(timeout or stage['timeout']),'--memory-limit-bytes',str(536870912 if stage['kind']=='sample' else 805306368),'--min-free-memory-bytes','3221225472','--disk-reserve-bytes','4294967296','--disk-path',str(root),'--grace-seconds','5','--kill-wait-seconds','5','--poll-seconds','0.05']
    fixed=[Path(__file__),plan_path,manifest_path,toolchain/'rustc.exe']
    fixed+=([inputs[stage['case']]] if stage['kind']=='sample' else [sources[stage['role']]/name for name in pins[stage['role']]])
    for path in fixed:args+=['--identity-file',str(path)]
    code=m.main(args+['--']+stage['argv']);check_sources();status=json.loads(record.read_bytes())
    item={'label':stage['label']+suffix,'record':m.identity(record),'supervisor_exit':code,'source_unchanged':True}
    result['stages'].append(item);print(json.dumps({'stage':item['label'],'state':status['state'],'code':code,'elapsed_seconds':status.get('elapsed_seconds')}),flush=True)
    return item,status
for stage in stages:
    item,status=run_stage(stage)
    compiled=targets[stage['role']]/'debug/examples/sol_codec_bench.exe'
    if item['supervisor_exit']!=0:
        recover=(stage['kind'] in ['build','test'] and status['child_exit_code']==0 and status['stop_reason']=='descendants_after_root_exit' and status['cleanup_complete'] and status['identity_unchanged'] and len(status['errors'])==1 and status['errors'][0]['where']=='graceful_signal' and 'AttachConsole' in status['errors'][0]['message'])
        if not recover:failure(stage['label'])
        before=m.identity(compiled); item,status=run_stage(stage,'-cleanup-confirmation',30);assert m.identity(compiled)==before
        item['compiled_binary_unchanged']=before
    if item['supervisor_exit']!=0 or status['errors'] or not status['cleanup_complete'] or not status['identity_unchanged']:failure(item['label'])
    if stage['kind']=='build':
        destination=root/'binaries'/(stage['role']+'.exe');before=m.identity(compiled);shutil.copyfile(compiled,destination);after=m.identity(destination);assert all(before[k]==after[k] for k in ('bytes','sha256'))
        assert b'R1_SOL_WRITE_PHASE_OUTPUT' not in destination.read_bytes(), 'unexpected instrumented binary'
        result['binaries'][stage['role']]={'compiled':before,'frozen':after}
    elif stage['kind']=='sample':
        output=root/'samples'/stage['label'];sample=json.loads((output/'result.json').read_bytes());assert sample['status']=='completed' and (output/'rewritten.sol').read_bytes()==inputs[stage['case']].read_bytes()
        item.update(sample=m.identity(output/'result.json'),operation_seconds=sample['timing']['operation_seconds'],artifacts={p.name:m.identity(p) for p in output.iterdir() if p.is_file()})
for case in inputs:
    for name in ['canonical.bin','root-canonical.bin']:
        expected=m.identity(root/'samples'/f'{case}-1-baseline'/name)
        for repeat in range(1,4):
            for role in sources:
                actual=m.identity(root/'samples'/f'{case}-{repeat}-{role}'/name);assert all(actual[k]==expected[k] for k in ('bytes','sha256'))
result['descriptive_medians']={case:{role:statistics.median(s['operation_seconds'] for s in result['stages'] if s['label'].startswith(case+'-') and s['label'].endswith('-'+role)) for role in sources} for case in inputs}
result.update(status='diagnostic_complete',ended_at=m.utc_now(),rewrites_equal_inputs=True,canonical_and_root_equal=True,source_unchanged=True,performance_acceptance='not_evaluated')
m.atomic_json(root/'result.json',result,initial=True);print(json.dumps({'status':result['status'],'descriptive_medians':result['descriptive_medians']}))
