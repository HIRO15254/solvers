from pathlib import Path
import importlib.util,json,os,shutil,sys,time,statistics
repo=Path(r'C:\Users\PC_User\.codex\worktrees\ce71\solvers'); root=Path(r'E:\codex-work\solvers\r1-context-reuse-20260926')
spec=importlib.util.spec_from_file_location('supervisor',repo/'tools/run_supervised.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
manifest_path=root/'source/r1-context-reuse-source.json';manifest=json.loads(manifest_path.read_bytes())
sources={'baseline':Path(manifest['source_path']),'candidate':root/'source'}
pins={'baseline':manifest['before'],'candidate':manifest['after']}
for folder in ['records','inputs','binaries','samples']:(root/folder).mkdir()
selection_path=repo/'experiments/hu-postflop-r1/codec/inputs.json';selection=json.loads(selection_path.read_bytes())
for case,ref in selection['cases'].items():
    raw=(repo/'runs/r1-cloud/codec-inputs07'/(case+'.sol')).read_bytes()
    assert len(raw)==ref['bytes'] and __import__('hashlib').sha256(raw).hexdigest()==ref['sha256']
    (root/'inputs'/(case+'.sol')).write_bytes(raw)
toolchain=Path(r'C:\Users\PC_User\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin')
target=Path(r'E:\codex-work\solvers\target\r1-writer-smoke-20260926')
# Reuse dependency cache only after the old instrumented executable is Git-retained.
assert (repo/'experiments/hu-postflop-r1/codec/write-phases/windows-smoke-20260926/binary/sol_codec_bench.exe.gz').is_file()
environment={'CARGO_BUILD_JOBS':'1','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(target),'CARGO_NET_OFFLINE':'true','RUSTFLAGS':'','RUSTC':str(toolchain/'rustc.exe'),'RAYON_NUM_THREADS':'1','RUST_TEST_THREADS':'1'}
os.environ.update(environment);os.environ.pop('R1_SOL_WRITE_PHASE_OUTPUT',None)
cargo=str(toolchain/'cargo.exe')
base=[cargo,'build','--locked','--offline','-p','formats','--example','sol_codec_bench','--target-dir',str(target)]
stages=[{'label':'build-'+role,'role':role,'kind':'build','cwd':str(sources[role]),'argv':base,'timeout':180} for role in ['baseline','candidate']]
stages.append({'label':'formats-tests','role':'candidate','kind':'test','cwd':str(sources['candidate']),'argv':[cargo,'test','--locked','--offline','-p','formats','--target-dir',str(target),'--','--test-threads=1'],'timeout':180})
for case in ['river','turn','flop']:
    for repeat in range(1,4):
        for role in (['baseline','candidate'] if repeat%2 else ['candidate','baseline']):
            label=f'{case}-{repeat}-{role}'
            stages.append({'label':label,'role':role,'kind':'sample','case':case,'repeat':repeat,'cwd':str(root),'argv':[str(root/'binaries'/(role+'.exe')),str(root/'inputs'/(case+'.sol')),'stream-write','1',str(root/'samples'/label)],'timeout':60})
def check_sources():
    for role in sources:
        for name,expected in pins[role].items():
            actual=m.identity(sources[role]/name);assert all(actual[k]==expected[k] for k in ('bytes','sha256')),(role,name)
check_sources()
assert m.WindowsAPI().memory()['available_bytes']>=4*1024**3
plan={'schema':'r1.context-reuse-local-diagnostic-plan/v1','created_at':m.utc_now(),'scope':'Windows debug same-toolchain three alternating pairs per existing River/Turn/Flop; local diagnostic, no dedicated-host performance certification or old Linux-regression attribution','source_manifest':m.identity(manifest_path),'source_files':pins,'sources':{k:str(v) for k,v in sources.items()},'environment':environment,'source_revision':manifest['source_revision'],'input_selection':m.identity(selection_path),'inputs':{case:m.identity(root/'inputs'/(case+'.sol')) for case in selection['cases']},'stages':stages,'overall_timeout_seconds':1200,'build_memory_bytes':805306368,'sample_memory_bytes':536870912,'min_free_memory_bytes':3221225472,'disk_reserve_bytes':4294967296,'r1_acceptance':None}
plan_path=root/'diagnostic-plan.json';m.atomic_json(plan_path,plan,initial=True)
result={'schema':'r1.context-reuse-local-diagnostic-result/v1','plan':m.identity(plan_path),'status':'running','stages':[],'binaries':{},'r1_acceptance':None}
started=time.monotonic()
for stage in stages:
    assert time.monotonic()-started+stage['timeout']+15<1200,'overall deadline'
    check_sources()
    record=root/'records'/(stage['label']+'.json')
    args=['--record',str(record),'--cwd',stage['cwd'],'--timeout-seconds',str(stage['timeout']),'--memory-limit-bytes',str(536870912 if stage['kind']=='sample' else 805306368),'--min-free-memory-bytes','3221225472','--disk-reserve-bytes','4294967296','--disk-path',str(root),'--grace-seconds','5','--kill-wait-seconds','5','--poll-seconds','0.05']
    fixed=[Path(__file__),plan_path,manifest_path,toolchain/'rustc.exe']
    fixed += ([root/'inputs'/(stage['case']+'.sol')] if stage['kind']=='sample' else [sources[stage['role']]/name for name in pins[stage['role']]])
    for path in fixed:args+=['--identity-file',str(path)]
    code=m.main(args+['--']+stage['argv']);check_sources()
    item={'label':stage['label'],'record':m.identity(record),'supervisor_exit':code,'source_unchanged':True}
    result['stages'].append(item)
    status=json.loads(record.read_bytes())
    if code!=0 or not status['cleanup_complete'] or not status['identity_unchanged'] or status['errors']:
        result.update(status='failed',first_failure=stage['label'],ended_at=m.utc_now());m.atomic_json(root/'diagnostic-result.json',result,initial=True);print(json.dumps(result));sys.exit(1)
    if stage['kind']=='build':
        compiled=target/'debug/examples/sol_codec_bench.exe'; destination=root/'binaries'/(stage['role']+'.exe')
        before=m.identity(compiled);shutil.copyfile(compiled,destination);after=m.identity(destination)
        assert all(before[k]==after[k] for k in ('bytes','sha256'))
        result['binaries'][stage['role']]={'compiled':before,'frozen':after}
    elif stage['kind']=='sample':
        output=root/'samples'/stage['label'];sample=json.loads((output/'result.json').read_bytes())
        assert sample['status']=='completed' and (output/'rewritten.sol').read_bytes()==(root/'inputs'/(stage['case']+'.sol')).read_bytes()
        item.update(sample=m.identity(output/'result.json'),operation_seconds=sample['timing']['operation_seconds'],artifacts={p.name:m.identity(p) for p in output.iterdir() if p.is_file()})
    print(json.dumps({'stage':stage['label'],'supervisor_exit':code,'elapsed_seconds':status['elapsed_seconds']}),flush=True)
for case in selection['cases']:
    for name in ['canonical.bin','root-canonical.bin']:
        expected=m.identity(root/'samples'/(case+'-1-baseline')/name)
        for repeat in range(1,4):
            for role in ['baseline','candidate']:
                actual=m.identity(root/'samples'/f'{case}-{repeat}-{role}'/name)
                assert all(actual[k]==expected[k] for k in ('bytes','sha256'))
result['descriptive_medians']={case:{role:statistics.median(s['operation_seconds'] for s in result['stages'] if s['label'].startswith(case+'-') and s['label'].endswith('-'+role)) for role in ['baseline','candidate']} for case in selection['cases']}
result.update(status='diagnostic_complete',ended_at=m.utc_now(),rewrites_equal_inputs=True,canonical_and_root_equal=True,source_unchanged=True,performance_acceptance='not_evaluated')
m.atomic_json(root/'diagnostic-result.json',result,initial=True);print(json.dumps({'status':result['status'],'descriptive_medians':result['descriptive_medians']}))
