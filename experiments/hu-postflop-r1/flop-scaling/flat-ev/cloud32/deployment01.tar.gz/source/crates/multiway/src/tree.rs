//! Public betting-tree enumeration and dense-arena preallocation backing
//! [`crate::config::RecallMode::Street`].
//!
//! No chance branching exists in this game family (chance is sampled once,
//! up front, outside the public tree; see [`crate::solver::ExternalSamplingGame`]),
//! so the entire public game tree is deterministic and can be walked once,
//! independent of any physical card world. [`enumerate_tree`] does exactly
//! that; [`build_arena`] then sizes and preallocates one contiguous,
//! node-major `[node][bucket][action]` arena of regrets/strategy sums for
//! every information set the tree can ever reach, so a Street-recall solve's
//! policy-arena footprint is fixed at preflight time instead of growing with
//! the number of visited information sets. The public tree, abstraction
//! caches, worker scratch, evaluation, and artifact staging remain additional
//! process memory.

use std::ops::Range;
use std::sync::atomic::{AtomicUsize, Ordering};

use rayon::prelude::*;
use rustc_hash::FxHashMap;

use crate::abstraction::BucketId;
use crate::solver::{ExternalSamplingGame, HistoryKey};
use crate::types::Street;

/// Preorder index into [`PublicTree::nodes`]. Root is always `0`.
pub type NodeId = u32;

/// Representation limit for a fully materialized public tree.
///
/// This is not a production resource policy. Production feasibility is
/// governed by the solver's byte limit via [`preflight_arena_with_limits`].
/// The bound only guarantees that every materialized node has a distinct
/// [`NodeId`].
pub const MAX_TREE_NODES: usize = (NodeId::MAX as usize).saturating_add(1);

/// Maximum number of dense columns addressable by a `u32` wire column id.
const MAX_DENSE_COLUMNS: u64 = u32::MAX as u64 + 1;

/// One action's destination out of a decision node: either another decision
/// node, or a terminal state (settlement happens outside the public tree,
/// so terminals are not materialized as nodes).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Child {
    Decision(NodeId),
    Terminal,
}

/// One public decision node. `action_labels` is the single shared label list
/// for every bucket at this node (there is exactly one legal-action shape
/// per public node, independent of private information), reused both to
/// build [`crate::solver::HistoryEntry`] edges and as every column's
/// `PolicyColumn::action_labels` in the dense arena.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TreeNode {
    pub history: HistoryKey,
    /// `None` only at the root.
    pub parent: Option<NodeId>,
    /// Index into the parent's `action_labels`/`children` that reaches this
    /// node. Meaningless (`0`) at the root.
    pub parent_action_index: u32,
    pub actor: u8,
    pub street: Street,
    /// Current non-folded opponent count excluding `actor`, matching what
    /// [`crate::solver::PrivateInfo::active_opponents`] carries for any
    /// physical world at this node (folding is public).
    pub active_opponents: u8,
    /// Opponent count `bucket()` feeds the abstraction for this node's
    /// street (the count as of that street's start; see
    /// `BettingState::players_on_street`). This can differ from
    /// `active_opponents` once a same-street fold has happened, since a
    /// street's abstraction context is fixed at that street's start.
    pub bucket_active_opponents: u8,
    pub action_labels: Vec<String>,
    /// Same length and order as `action_labels`.
    pub children: Vec<Child>,
}

/// The fully enumerated public betting tree, in preorder.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct PublicTree {
    pub nodes: Vec<TreeNode>,
    pub by_history: FxHashMap<HistoryKey, NodeId>,
}

/// Non-retaining census of a public tree and its dense policy arena.
///
/// The counts describe the complete tree when
/// [`preflight_arena_with_limits`] returns `Ok`. A byte or node limit error
/// instead reports the first prefix that crossed the corresponding resource
/// boundary.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct TreePreflight {
    pub node_count: usize,
    pub terminal_edges: u64,
    pub total_columns: u64,
    pub total_slots: u64,
    pub estimated_arena_bytes: u64,
}

/// Walks the public game tree once, deterministically, from
/// `game.root_state()`. Only decision nodes are recorded; terminals are
/// [`Child::Terminal`] markers on their parent. The only implicit node bound
/// is the [`NodeId`] representation limit; production callers should run the
/// byte- and depth-bounded APIs first. This convenience wrapper is for
/// trusted finite games.
pub fn enumerate_tree<G: ExternalSamplingGame>(game: &G) -> Result<PublicTree, TreeError> {
    enumerate_tree_with_limit(game, MAX_TREE_NODES)
}

/// Walks the public game tree with a caller-selected decision-node cap.
///
/// This is intended for callers that explicitly want a node checkpoint. The
/// requested limit is clamped only to the [`NodeId`] representation limit,
/// not to a production policy constant.
pub fn enumerate_tree_with_limit<G: ExternalSamplingGame>(
    game: &G,
    max_nodes: usize,
) -> Result<PublicTree, TreeError> {
    enumerate_tree_with_limits(game, max_nodes, u32::MAX)
}

/// Materializes a public tree with explicit representation/checkpoint and
/// structural-depth bounds.
///
/// Production dense storage passes the same traversal-depth guard used by
/// MCCFR so a malformed cyclic adapter fails as a typed error instead of
/// recursing until stack overflow.
pub fn enumerate_tree_with_limits<G: ExternalSamplingGame>(
    game: &G,
    max_nodes: usize,
    max_depth: u32,
) -> Result<PublicTree, TreeError> {
    let root = game.root_state();
    if game.actor(&root).is_none() {
        return Err(TreeError::RootIsTerminal);
    }
    let max_nodes = max_nodes.min(MAX_TREE_NODES);
    let mut nodes = Vec::new();
    let mut by_history = FxHashMap::default();
    enumerate_node(
        game,
        root,
        HistoryKey::ROOT,
        None,
        0,
        0,
        max_nodes,
        max_depth,
        &mut nodes,
        &mut by_history,
        true,
        None,
    )?;
    Ok(PublicTree { nodes, by_history })
}

// Keep the planning prefix small even when the ambient Rayon pool is very
// large. The retained prefix is at most a shallow tree with this many leaves;
// the independently materialized subtree vectors share a separate global
// node budget below.
const PARALLEL_FRONTIER_TASKS_PER_THREAD: usize = 4;
const MAX_PARALLEL_FRONTIER_TASKS: usize = 64;
const MAX_PARALLEL_PREFIX_DEPTH: u32 = 4;

struct ParallelFrontier<S> {
    state: S,
    history: HistoryKey,
    depth: u32,
}

enum ParallelPlan<S> {
    Frontier(ParallelFrontier<S>),
    Expanded(ParallelPlanNode<S>),
    Ready(usize),
}

struct ParallelPlanNode<S> {
    history: HistoryKey,
    actor: u8,
    street: Street,
    active_opponents: u8,
    bucket_active_opponents: u8,
    action_labels: Vec<String>,
    children: Vec<ParallelPlanChild<S>>,
}

enum ParallelPlanChild<S> {
    Decision(Box<ParallelPlan<S>>),
    Terminal,
}

/// Materializer that preserves the serial preorder while enumerating
/// bounded, independent public subtrees on the current Rayon pool.
///
/// One-thread pools use [`enumerate_tree_with_limits`] directly. Multi-thread
/// pools retain at most 64 frontier tasks and a depth-four planning prefix.
/// All subtree workers share the caller's decision-node allowance, so their
/// aggregate retained node count cannot grow beyond `max_nodes` (in addition
/// to the bounded prefix). Completed subtrees are compact boxed slices.
/// Ordered merging moves each subtree's node records; it does not clone their
/// action-label or child buffers. The merge can temporarily retain at most
/// `2 * max_nodes` `TreeNode` slots (source slices plus the exactly-sized
/// destination), in addition to the bounded prefix and active worker `Vec`
/// capacity. Production callers first run non-retaining resource admission,
/// supply its exact node count, and select an explicitly sized private pool.
/// Neither this allowance nor the arena budget is a process-RSS guarantee.
///
/// If planning, a worker, or ordered merge encounters an error, the serial
/// oracle is rerun after all parallel state and node buffers are released.
/// That preserves the existing depth-first error priority and exact error
/// payload rather than exposing scheduler order. The merge destination uses
/// fallible reservation; allocation failure takes the same released-state
/// serial retry path.
#[doc(hidden)]
pub fn enumerate_tree_with_limits_parallel<G: ExternalSamplingGame>(
    game: &G,
    max_nodes: usize,
    max_depth: u32,
) -> Result<PublicTree, TreeError>
where
    G::State: Send,
{
    let threads = rayon::current_num_threads();
    if threads <= 1 {
        return enumerate_tree_with_limits(game, max_nodes, max_depth);
    }
    let max_nodes = max_nodes.min(MAX_TREE_NODES);
    // Keep every parallel allocation inside the attempt. In particular, a
    // serial retry must not coexist with completed subtrees or a partial
    // destination from a failed ordered merge.
    match enumerate_tree_parallel_attempt(game, max_nodes, max_depth, threads) {
        Ok(Some(tree)) => Ok(tree),
        Ok(None) | Err(_) => enumerate_tree_with_limits(game, max_nodes, max_depth),
    }
}

fn enumerate_tree_parallel_attempt<G: ExternalSamplingGame>(
    game: &G,
    max_nodes: usize,
    max_depth: u32,
    threads: usize,
) -> Result<Option<PublicTree>, TreeError>
where
    G::State: Send,
{
    let root = game.root_state();
    if game.actor(&root).is_none() {
        return Err(TreeError::RootIsTerminal);
    }

    let target_tasks = threads
        .saturating_mul(PARALLEL_FRONTIER_TASKS_PER_THREAD)
        .clamp(2, MAX_PARALLEL_FRONTIER_TASKS);
    let mut plan = ParallelPlan::Frontier(ParallelFrontier {
        state: root,
        history: HistoryKey::ROOT,
        depth: 0,
    });
    let mut frontier_count = 1usize;
    while frontier_count < target_tasks {
        match expand_one_parallel_frontier(
            game,
            &mut plan,
            frontier_count,
            MAX_PARALLEL_FRONTIER_TASKS,
            max_depth,
        )? {
            Some(next_count) => frontier_count = next_count,
            None => break,
        }
    }

    let prefix_nodes = count_parallel_prefix_nodes(&plan);
    if prefix_nodes > max_nodes {
        return Err(TreeError::TooManyNodes { limit: max_nodes });
    }
    let mut tasks = Vec::with_capacity(frontier_count);
    extract_parallel_frontiers(&mut plan, &mut tasks);
    if tasks.len() <= 1 {
        return Ok(None);
    }

    let parallel_nodes_remaining = AtomicUsize::new(max_nodes - prefix_nodes);
    let results: Vec<Result<Box<[TreeNode]>, TreeError>> = tasks
        .into_par_iter()
        .map(|task| {
            let mut nodes = Vec::new();
            // History entries are rebuilt once, in final preorder. Avoid a
            // full per-subtree map while the result vectors coexist.
            let mut unused_history = FxHashMap::default();
            enumerate_node(
                game,
                task.state,
                task.history,
                None,
                0,
                task.depth,
                max_nodes,
                max_depth,
                &mut nodes,
                &mut unused_history,
                false,
                Some(&parallel_nodes_remaining),
            )?;
            Ok(nodes.into_boxed_slice())
        })
        .collect();
    let mut subtree_nodes: Vec<Option<Box<[TreeNode]>>> = results
        .into_iter()
        .map(|result| result.map(Some))
        .collect::<Result<_, _>>()?;
    let total_nodes = subtree_nodes
        .iter()
        .try_fold(prefix_nodes, |total, nodes| {
            total.checked_add(nodes.as_ref().map_or(0, |nodes| nodes.len()))
        })
        .ok_or(TreeError::SizeOverflow)?;
    if total_nodes > max_nodes || total_nodes > MAX_TREE_NODES {
        return Err(TreeError::TooManyNodes { limit: max_nodes });
    }

    let mut nodes = reserve_parallel_merge_nodes(total_nodes)?;
    merge_parallel_plan(&mut plan, None, 0, &mut subtree_nodes, &mut nodes)?;
    if nodes.len() != total_nodes {
        return Err(TreeError::SizeOverflow);
    }
    let mut by_history = FxHashMap::default();
    for (index, node) in nodes.iter().enumerate() {
        by_history.insert(node.history, index as NodeId);
    }
    Ok(Some(PublicTree { nodes, by_history }))
}

fn reserve_parallel_merge_nodes(total_nodes: usize) -> Result<Vec<TreeNode>, TreeError> {
    let requested_bytes = total_nodes
        .checked_mul(std::mem::size_of::<TreeNode>())
        .ok_or(TreeError::SizeOverflow)?;
    let mut nodes = Vec::new();
    nodes
        .try_reserve_exact(total_nodes)
        .map_err(|_| TreeError::AllocationFailed {
            buffer: "parallel-tree-merge",
            requested_bytes,
        })?;
    Ok(nodes)
}

fn expand_one_parallel_frontier<G: ExternalSamplingGame>(
    game: &G,
    plan: &mut ParallelPlan<G::State>,
    frontier_count: usize,
    max_frontiers: usize,
    max_depth: u32,
) -> Result<Option<usize>, TreeError> {
    match plan {
        ParallelPlan::Frontier(frontier) => {
            if frontier.depth >= MAX_PARALLEL_PREFIX_DEPTH {
                return Ok(None);
            }
            let expanded = expand_parallel_frontier(game, frontier, max_depth)?;
            let added = expanded
                .children
                .iter()
                .filter(|child| matches!(child, ParallelPlanChild::Decision(_)))
                .count();
            let next_count = frontier_count
                .checked_sub(1)
                .and_then(|count| count.checked_add(added))
                .ok_or(TreeError::SizeOverflow)?;
            if next_count > max_frontiers {
                return Ok(None);
            }
            *plan = ParallelPlan::Expanded(expanded);
            Ok(Some(next_count))
        }
        ParallelPlan::Expanded(node) => {
            for child in &mut node.children {
                if let ParallelPlanChild::Decision(child_plan) = child
                    && let Some(next_count) = expand_one_parallel_frontier(
                        game,
                        child_plan,
                        frontier_count,
                        max_frontiers,
                        max_depth,
                    )?
                {
                    return Ok(Some(next_count));
                }
            }
            Ok(None)
        }
        ParallelPlan::Ready(_) => Ok(None),
    }
}

fn expand_parallel_frontier<G: ExternalSamplingGame>(
    game: &G,
    frontier: &ParallelFrontier<G::State>,
    max_depth: u32,
) -> Result<ParallelPlanNode<G::State>, TreeError> {
    if frontier.depth > max_depth {
        return Err(TreeError::DepthLimit { limit: max_depth });
    }
    let actor = game
        .actor(&frontier.state)
        .expect("frontier contains only decision states");
    let actions = game.node_actions(&frontier.state);
    let num_actions = game.num_actions_of(&actions);
    if num_actions == 0 {
        return Err(TreeError::NoActions { actor });
    }
    if u32::try_from(num_actions).is_err() {
        return Err(TreeError::SizeOverflow);
    }
    let mut action_labels = Vec::with_capacity(num_actions);
    let mut label_buf = String::new();
    for index in 0..num_actions {
        label_buf.clear();
        game.write_action_label(&actions, index, &mut label_buf);
        // The planner's local node id is immaterial: any error reruns the
        // serial oracle, which supplies the canonical global id.
        if label_buf.is_empty() {
            return Err(TreeError::EmptyActionLabel { node: 0 });
        }
        if action_labels.contains(&label_buf) {
            return Err(TreeError::DuplicateActionLabel { node: 0 });
        }
        action_labels.push(std::mem::take(&mut label_buf));
    }
    let context = game.dense_node_context(&frontier.state);
    let mut children = Vec::with_capacity(num_actions);
    for index in 0..num_actions {
        let child_depth = frontier
            .depth
            .checked_add(1)
            .ok_or(TreeError::DepthLimit { limit: max_depth })?;
        if child_depth > max_depth {
            return Err(TreeError::DepthLimit { limit: max_depth });
        }
        let child_state = game.next_state_with(&frontier.state, &actions, index);
        if game.actor(&child_state).is_none() {
            children.push(ParallelPlanChild::Terminal);
        } else {
            children.push(ParallelPlanChild::Decision(Box::new(
                ParallelPlan::Frontier(ParallelFrontier {
                    state: child_state,
                    history: frontier.history.child(actor, index),
                    depth: child_depth,
                }),
            )));
        }
    }
    Ok(ParallelPlanNode {
        history: frontier.history,
        actor: actor as u8,
        street: context.street,
        active_opponents: context.active_opponents,
        bucket_active_opponents: context.bucket_active_opponents,
        action_labels,
        children,
    })
}

fn count_parallel_prefix_nodes<S>(plan: &ParallelPlan<S>) -> usize {
    match plan {
        ParallelPlan::Expanded(node) => {
            1 + node
                .children
                .iter()
                .map(|child| match child {
                    ParallelPlanChild::Decision(child) => count_parallel_prefix_nodes(child),
                    ParallelPlanChild::Terminal => 0,
                })
                .sum::<usize>()
        }
        ParallelPlan::Frontier(_) | ParallelPlan::Ready(_) => 0,
    }
}

fn extract_parallel_frontiers<S>(plan: &mut ParallelPlan<S>, tasks: &mut Vec<ParallelFrontier<S>>) {
    match plan {
        ParallelPlan::Frontier(_) => {
            let ready_index = tasks.len();
            let old = std::mem::replace(plan, ParallelPlan::Ready(ready_index));
            let ParallelPlan::Frontier(frontier) = old else {
                unreachable!();
            };
            tasks.push(frontier);
        }
        ParallelPlan::Expanded(node) => {
            for child in &mut node.children {
                if let ParallelPlanChild::Decision(child) = child {
                    extract_parallel_frontiers(child, tasks);
                }
            }
        }
        ParallelPlan::Ready(_) => {}
    }
}

fn merge_parallel_plan<S>(
    plan: &mut ParallelPlan<S>,
    parent: Option<NodeId>,
    parent_action_index: u32,
    subtrees: &mut [Option<Box<[TreeNode]>>],
    nodes: &mut Vec<TreeNode>,
) -> Result<NodeId, TreeError> {
    match plan {
        ParallelPlan::Expanded(node) => {
            let node_id = NodeId::try_from(nodes.len()).map_err(|_| TreeError::SizeOverflow)?;
            nodes.push(TreeNode {
                history: node.history,
                parent,
                parent_action_index,
                actor: node.actor,
                street: node.street,
                active_opponents: node.active_opponents,
                bucket_active_opponents: node.bucket_active_opponents,
                action_labels: std::mem::take(&mut node.action_labels),
                children: Vec::new(),
            });
            let mut children = Vec::with_capacity(node.children.len());
            for (action_index, child) in node.children.iter_mut().enumerate() {
                match child {
                    ParallelPlanChild::Terminal => children.push(Child::Terminal),
                    ParallelPlanChild::Decision(child) => {
                        let child_id = merge_parallel_plan(
                            child,
                            Some(node_id),
                            action_index as u32,
                            subtrees,
                            nodes,
                        )?;
                        children.push(Child::Decision(child_id));
                    }
                }
            }
            nodes[node_id as usize].children = children;
            Ok(node_id)
        }
        ParallelPlan::Ready(index) => {
            let subtree = subtrees
                .get_mut(*index)
                .and_then(Option::take)
                .ok_or(TreeError::SizeOverflow)?;
            let offset = NodeId::try_from(nodes.len()).map_err(|_| TreeError::SizeOverflow)?;
            let mut subtree = subtree.into_vec();
            for (local_index, node) in subtree.iter_mut().enumerate() {
                if local_index == 0 {
                    node.parent = parent;
                    node.parent_action_index = parent_action_index;
                } else if let Some(local_parent) = node.parent {
                    node.parent = Some(
                        offset
                            .checked_add(local_parent)
                            .ok_or(TreeError::SizeOverflow)?,
                    );
                }
                for child in &mut node.children {
                    if let Child::Decision(local_child) = child {
                        *local_child = offset
                            .checked_add(*local_child)
                            .ok_or(TreeError::SizeOverflow)?;
                    }
                }
            }
            nodes.append(&mut subtree);
            Ok(offset)
        }
        ParallelPlan::Frontier(_) => Err(TreeError::SizeOverflow),
    }
}

/// Measures the full public tree without retaining its nodes and stops at
/// the solver's dense-arena byte limit.
///
/// Production dense storage calls this before materializing the tree, so an
/// infeasible action abstraction fails with [`TreeError::MemoryLimit`]
/// instead of first allocating an arbitrary fixed number of public nodes.
/// This convenience wrapper assumes a trusted finite game; production uses
/// [`preflight_arena_with_limits_and_depth`].
pub fn preflight_arena<G: ExternalSamplingGame>(
    game: &G,
    max_memory_bytes: u64,
) -> Result<TreePreflight, TreeError> {
    preflight_arena_with_limits(game, MAX_TREE_NODES, max_memory_bytes)
}

/// Non-retaining public-tree/dense-arena census with explicit resource
/// limits.
///
/// `max_nodes` is useful as an optional benchmark checkpoint. It is not a
/// production default. The function attempts node `max_nodes + 1` before
/// returning [`TreeError::TooManyNodes`], and returns
/// [`TreeError::MemoryLimit`] at the first node whose cumulative dense-arena
/// estimate strictly exceeds `max_memory_bytes`.
pub fn preflight_arena_with_limits<G: ExternalSamplingGame>(
    game: &G,
    max_nodes: usize,
    max_memory_bytes: u64,
) -> Result<TreePreflight, TreeError> {
    preflight_arena_with_limits_and_depth(game, max_nodes, max_memory_bytes, u32::MAX)
}

/// Non-retaining census with explicit node, arena-byte, and structural
/// depth bounds.
pub fn preflight_arena_with_limits_and_depth<G: ExternalSamplingGame>(
    game: &G,
    max_nodes: usize,
    max_memory_bytes: u64,
    max_depth: u32,
) -> Result<TreePreflight, TreeError> {
    let root = game.root_state();
    if game.actor(&root).is_none() {
        return Err(TreeError::RootIsTerminal);
    }
    let max_nodes = max_nodes.min(MAX_TREE_NODES);
    let mut preflight = TreePreflight::default();
    preflight_node(
        game,
        root,
        0,
        max_nodes,
        max_memory_bytes,
        max_depth,
        &mut preflight,
    )?;
    Ok(preflight)
}

fn preflight_node<G: ExternalSamplingGame>(
    game: &G,
    state: G::State,
    depth: u32,
    max_nodes: usize,
    max_memory_bytes: u64,
    max_depth: u32,
    preflight: &mut TreePreflight,
) -> Result<(), TreeError> {
    if depth > max_depth {
        return Err(TreeError::DepthLimit { limit: max_depth });
    }
    let actor = game
        .actor(&state)
        .expect("caller only recurses into decision states");
    if preflight.node_count >= max_nodes {
        return Err(TreeError::TooManyNodes { limit: max_nodes });
    }
    let node_id = preflight.node_count as NodeId;
    let actions = game.node_actions(&state);
    let num_actions = game.num_actions_of(&actions);
    if num_actions == 0 {
        return Err(TreeError::NoActions { actor });
    }
    if u32::try_from(num_actions).is_err() {
        return Err(TreeError::SizeOverflow);
    }

    // Validate the same public action-label contract as full enumeration
    // while retaining only one node's small menu.
    let mut action_labels = Vec::with_capacity(num_actions);
    let mut label_buf = String::new();
    for index in 0..num_actions {
        label_buf.clear();
        game.write_action_label(&actions, index, &mut label_buf);
        if label_buf.is_empty() {
            return Err(TreeError::EmptyActionLabel { node: node_id });
        }
        if action_labels.contains(&label_buf) {
            return Err(TreeError::DuplicateActionLabel { node: node_id });
        }
        action_labels.push(std::mem::take(&mut label_buf));
    }

    let context = game.dense_node_context(&state);
    let buckets = u64::from(game.bucket_count(context.street, context.bucket_active_opponents));
    if buckets == 0 {
        return Err(TreeError::ZeroBuckets);
    }
    let slots = buckets
        .checked_mul(num_actions as u64)
        .ok_or(TreeError::SizeOverflow)?;
    preflight.node_count += 1;
    preflight.total_columns = preflight
        .total_columns
        .checked_add(buckets)
        .ok_or(TreeError::SizeOverflow)?;
    if preflight.total_columns > MAX_DENSE_COLUMNS {
        return Err(TreeError::ColumnIdOverflow);
    }
    preflight.total_slots = preflight
        .total_slots
        .checked_add(slots)
        .ok_or(TreeError::SizeOverflow)?;
    preflight.estimated_arena_bytes = estimate_bytes(
        preflight.node_count,
        preflight.total_columns,
        preflight.total_slots,
    )?;
    if preflight.estimated_arena_bytes > max_memory_bytes {
        return Err(TreeError::MemoryLimit {
            node_count: preflight.node_count,
            total_columns: preflight.total_columns,
            limit: max_memory_bytes,
            needed: preflight.estimated_arena_bytes,
        });
    }

    for index in 0..num_actions {
        let child_depth = depth
            .checked_add(1)
            .ok_or(TreeError::DepthLimit { limit: max_depth })?;
        if child_depth > max_depth {
            return Err(TreeError::DepthLimit { limit: max_depth });
        }
        let child_state = game.next_state_with(&state, &actions, index);
        if game.actor(&child_state).is_some() {
            preflight_node(
                game,
                child_state,
                child_depth,
                max_nodes,
                max_memory_bytes,
                max_depth,
                preflight,
            )?;
        } else {
            preflight.terminal_edges = preflight
                .terminal_edges
                .checked_add(1)
                .ok_or(TreeError::SizeOverflow)?;
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn enumerate_node<G: ExternalSamplingGame>(
    game: &G,
    state: G::State,
    history: HistoryKey,
    parent: Option<NodeId>,
    parent_action_index: u32,
    depth: u32,
    max_nodes: usize,
    max_depth: u32,
    nodes: &mut Vec<TreeNode>,
    by_history: &mut FxHashMap<HistoryKey, NodeId>,
    record_history: bool,
    parallel_nodes_remaining: Option<&AtomicUsize>,
) -> Result<NodeId, TreeError> {
    if depth > max_depth {
        return Err(TreeError::DepthLimit { limit: max_depth });
    }
    let actor = game
        .actor(&state)
        .expect("caller only recurses into decision states");
    if nodes.len() >= max_nodes {
        return Err(TreeError::TooManyNodes { limit: max_nodes });
    }
    if let Some(remaining) = parallel_nodes_remaining
        && remaining
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |count| {
                count.checked_sub(1)
            })
            .is_err()
    {
        return Err(TreeError::TooManyNodes { limit: max_nodes });
    }
    let node_id = nodes.len() as NodeId;
    let actions = game.node_actions(&state);
    let num_actions = game.num_actions_of(&actions);
    if num_actions == 0 {
        return Err(TreeError::NoActions { actor });
    }
    if u32::try_from(num_actions).is_err() {
        return Err(TreeError::SizeOverflow);
    }
    let mut action_labels = Vec::with_capacity(num_actions);
    let mut label_buf = String::new();
    for index in 0..num_actions {
        label_buf.clear();
        game.write_action_label(&actions, index, &mut label_buf);
        if label_buf.is_empty() {
            return Err(TreeError::EmptyActionLabel { node: node_id });
        }
        if action_labels.contains(&label_buf) {
            return Err(TreeError::DuplicateActionLabel { node: node_id });
        }
        action_labels.push(std::mem::take(&mut label_buf));
    }
    let context = game.dense_node_context(&state);

    nodes.push(TreeNode {
        history,
        parent,
        parent_action_index,
        actor: actor as u8,
        street: context.street,
        active_opponents: context.active_opponents,
        bucket_active_opponents: context.bucket_active_opponents,
        action_labels,
        children: Vec::new(),
    });
    if record_history {
        by_history.insert(history, node_id);
    }

    let mut children = Vec::with_capacity(num_actions);
    for index in 0..num_actions {
        let child_depth = depth
            .checked_add(1)
            .ok_or(TreeError::DepthLimit { limit: max_depth })?;
        if child_depth > max_depth {
            return Err(TreeError::DepthLimit { limit: max_depth });
        }
        let child_state = game.next_state_with(&state, &actions, index);
        let child_history = history.child(actor, index);
        if game.actor(&child_state).is_none() {
            children.push(Child::Terminal);
        } else {
            let child_id = enumerate_node(
                game,
                child_state,
                child_history,
                Some(node_id),
                index as u32,
                child_depth,
                max_nodes,
                max_depth,
                nodes,
                by_history,
                record_history,
                parallel_nodes_remaining,
            )?;
            children.push(Child::Decision(child_id));
        }
    }
    nodes[node_id as usize].children = children;
    Ok(node_id)
}

/// Purely public per-node context an [`ExternalSamplingGame`] implementor
/// supplies for dense-arena preallocation; see [`TreeNode`] field docs.
#[derive(Clone, Copy, Debug)]
pub struct DenseNodeContext {
    pub street: Street,
    pub active_opponents: u8,
    pub bucket_active_opponents: u8,
}

/// Node-major contiguous `[node][bucket][action]` policy storage for every
/// information set the enumerated tree can reach. Preallocated once at
/// preflight time; memory is therefore fixed for the run's lifetime.
#[derive(Debug)]
pub struct DenseArena {
    /// Cumulative bucket counts; length `nodes.len() + 1`. Node `n`'s
    /// columns are `column_base[n]..column_base[n + 1]`.
    column_base: Vec<u64>,
    /// Cumulative `bucket_count * num_actions`; length `nodes.len() + 1`.
    slot_base: Vec<u64>,
    bucket_count: Vec<u32>,
    num_actions: Vec<u32>,
    pub regrets: Vec<f32>,
    pub strategy_sum: Vec<f32>,
    touched: Vec<u64>,
    total_columns: u64,
    total_slots: u64,
    touched_count: u64,
    estimated_bytes: u64,
    /// `true` only after every OS page backing the fixed policy payload has
    /// been written at least once. Ordinary research/library construction
    /// may leave this false; the production constructor requires it before
    /// returning a solver.
    pages_committed: bool,
}

impl DenseArena {
    pub fn node_count(&self) -> usize {
        self.bucket_count.len()
    }

    pub fn total_columns(&self) -> u64 {
        self.total_columns
    }

    pub fn total_slots(&self) -> u64 {
        self.total_slots
    }

    pub fn estimated_bytes(&self) -> u64 {
        self.estimated_bytes
    }

    pub fn touched_count(&self) -> u64 {
        self.touched_count
    }

    pub fn pages_committed(&self) -> bool {
        self.pages_committed
    }

    #[cfg(test)]
    pub(crate) fn touched_storage_layout(&self) -> (*const u64, usize, usize) {
        (
            self.touched.as_ptr(),
            self.touched.len(),
            self.touched.capacity(),
        )
    }

    /// Faults in every page of the fixed policy payload. This turns the
    /// allocator's potentially demand-zero/overcommitted reservation into a
    /// startup barrier: a production solver is not returned until the
    /// regret, strategy-sum, and touched-bit buffers have all been written.
    ///
    /// This does not claim that the whole process fits the solver payload
    /// limit. The public tree, abstraction tables, worker scratch, and
    /// allocator overhead remain additional process memory.
    #[doc(hidden)]
    pub fn commit_pages(&mut self) {
        commit_slice_pages(&mut self.regrets);
        commit_slice_pages(&mut self.strategy_sum);
        commit_slice_pages(&mut self.touched);
        self.pages_committed = true;
    }

    pub fn bucket_count_of(&self, node: NodeId) -> u32 {
        self.bucket_count[node as usize]
    }

    /// Global column id for `(node, bucket)`, used both to address the
    /// touched-bitset and as the traversal delta's wire-format column id.
    pub fn column_id(&self, node: NodeId, bucket: BucketId) -> Result<u32, TreeError> {
        let count = self.bucket_count[node as usize];
        if bucket >= count {
            return Err(TreeError::BucketOutOfRange {
                node,
                bucket,
                count,
            });
        }
        let column = self.column_base[node as usize] + u64::from(bucket);
        u32::try_from(column).map_err(|_| TreeError::ColumnIdOverflow)
    }

    /// Slot range (into [`Self::regrets`]/[`Self::strategy_sum`]) for
    /// `(node, bucket)`'s `num_actions(node)`-long action vector.
    pub fn slot_range(&self, node: NodeId, bucket: BucketId) -> Result<Range<usize>, TreeError> {
        let count = self.bucket_count[node as usize];
        if bucket >= count {
            return Err(TreeError::BucketOutOfRange {
                node,
                bucket,
                count,
            });
        }
        let num_actions = u64::from(self.num_actions[node as usize]);
        let start = self.slot_base[node as usize] + u64::from(bucket) * num_actions;
        let end = start + num_actions;
        Ok(start as usize..end as usize)
    }

    /// Resolves a wire-format `column_id` back to its slot range, checking
    /// the caller's expected action count against the node's actual one.
    pub fn slot_range_for_column(
        &self,
        column: u32,
        expected_actions: usize,
    ) -> Result<Range<usize>, TreeError> {
        let node = self.node_for_column(column)?;
        let bucket = (u64::from(column) - self.column_base[node as usize]) as u32;
        let range = self.slot_range(node, bucket)?;
        if range.len() != expected_actions {
            return Err(TreeError::ActionCountMismatch);
        }
        Ok(range)
    }

    fn node_for_column(&self, column: u32) -> Result<NodeId, TreeError> {
        let column = u64::from(column);
        if column >= self.total_columns {
            return Err(TreeError::ColumnOutOfRange(column));
        }
        // `column_base` is sorted ascending; find the last index whose base
        // does not exceed `column`.
        let idx = self.column_base.partition_point(|&base| base <= column) - 1;
        Ok(idx as NodeId)
    }

    pub fn is_touched(&self, column: u32) -> bool {
        let column = column as usize;
        let word = self.touched[column / 64];
        (word >> (column % 64)) & 1 != 0
    }

    /// Sets `column`'s touched bit, returning `true` iff this call is the
    /// first time it was set (and bumping [`Self::touched_count`] exactly
    /// once per column over the arena's lifetime).
    pub fn touched_set(&mut self, column: u32) -> bool {
        let index = column as usize;
        let word = index / 64;
        let mask = 1u64 << (index % 64);
        let already = self.touched[word] & mask != 0;
        if !already {
            self.touched[word] |= mask;
            self.touched_count += 1;
        }
        !already
    }
}

/// Enumerates `game`'s public tree, then sizes and preallocates a
/// [`DenseArena`] for it. Fails *before* allocating the (potentially huge)
/// regret/strategy-sum buffers when the estimate exceeds `max_memory_bytes`.
pub fn build_arena<G: ExternalSamplingGame>(
    game: &G,
    tree: &PublicTree,
    max_memory_bytes: u64,
) -> Result<DenseArena, TreeError> {
    let node_count = tree.nodes.len();
    let mut column_base = Vec::with_capacity(node_count + 1);
    let mut slot_base = Vec::with_capacity(node_count + 1);
    let mut bucket_count = Vec::with_capacity(node_count);
    let mut num_actions = Vec::with_capacity(node_count);
    column_base.push(0u64);
    slot_base.push(0u64);
    let mut total_columns = 0u64;
    let mut total_slots = 0u64;
    for node in &tree.nodes {
        let buckets = u64::from(game.bucket_count(node.street, node.bucket_active_opponents));
        if buckets == 0 {
            return Err(TreeError::ZeroBuckets);
        }
        let actions = node.action_labels.len() as u64;
        bucket_count.push(u32::try_from(buckets).map_err(|_| TreeError::SizeOverflow)?);
        num_actions.push(u32::try_from(actions).map_err(|_| TreeError::SizeOverflow)?);
        total_columns = total_columns
            .checked_add(buckets)
            .ok_or(TreeError::SizeOverflow)?;
        if total_columns > MAX_DENSE_COLUMNS {
            return Err(TreeError::ColumnIdOverflow);
        }
        let slots = buckets
            .checked_mul(actions)
            .ok_or(TreeError::SizeOverflow)?;
        total_slots = total_slots
            .checked_add(slots)
            .ok_or(TreeError::SizeOverflow)?;
        column_base.push(total_columns);
        slot_base.push(total_slots);
    }

    let estimated_bytes = estimate_bytes(node_count, total_columns, total_slots)?;
    if estimated_bytes > max_memory_bytes {
        return Err(TreeError::MemoryLimit {
            node_count,
            total_columns,
            limit: max_memory_bytes,
            needed: estimated_bytes,
        });
    }

    let total_slots_usize = usize::try_from(total_slots).map_err(|_| TreeError::SizeOverflow)?;
    let touched_words =
        usize::try_from(total_columns.div_ceil(64)).map_err(|_| TreeError::SizeOverflow)?;
    Ok(DenseArena {
        column_base,
        slot_base,
        bucket_count,
        num_actions,
        regrets: try_zeroed_vec(total_slots_usize, "regret")?,
        strategy_sum: try_zeroed_vec(total_slots_usize, "strategy-sum")?,
        touched: try_zeroed_vec(touched_words, "touched-bitset")?,
        total_columns,
        total_slots,
        touched_count: 0,
        estimated_bytes,
        pages_committed: false,
    })
}

fn try_zeroed_vec<T: Copy + Default>(
    len: usize,
    buffer: &'static str,
) -> Result<Vec<T>, TreeError> {
    let requested_bytes = len
        .checked_mul(std::mem::size_of::<T>())
        .ok_or(TreeError::SizeOverflow)?;
    let mut values = Vec::new();
    values
        .try_reserve_exact(len)
        .map_err(|_| TreeError::AllocationFailed {
            buffer,
            requested_bytes,
        })?;
    // `try_reserve_exact` above established the complete capacity. Resize
    // only initializes those slots and therefore cannot request more memory.
    values.resize(len, T::default());
    Ok(values)
}

fn commit_slice_pages<T: Copy + Default>(values: &mut [T]) {
    if values.is_empty() {
        return;
    }
    // 4 KiB is no larger than the base page size on supported production
    // platforms. Touching at this cadence therefore writes at least one
    // element in every actual page (and more than one on larger-page
    // systems). Volatile writes prevent the compiler from removing writes
    // whose value is already zero.
    let elements_per_touch = (4096 / std::mem::size_of::<T>()).max(1);
    for index in (0..values.len()).step_by(elements_per_touch) {
        // SAFETY: `index` comes from a range bounded by `values.len()`.
        unsafe {
            std::ptr::write_volatile(values.as_mut_ptr().add(index), T::default());
        }
    }
    let last = values.len() - 1;
    // SAFETY: a non-empty slice always contains `last`.
    unsafe {
        std::ptr::write_volatile(values.as_mut_ptr().add(last), T::default());
    }
}

/// Two `f32` arrays per slot (regrets + strategy sums) plus one touched bit
/// per column plus a small constant per-node table overhead
/// (`column_base`/`slot_base`/`bucket_count`/`num_actions` entries) and the
/// two trailing `u64` base-table sentinels. `Vec` headers, spare capacity,
/// allocator rounding, and the separate [`PublicTree`] remain process
/// overhead outside this payload estimate.
fn estimate_bytes(
    node_count: usize,
    total_columns: u64,
    total_slots: u64,
) -> Result<u64, TreeError> {
    let slot_bytes = total_slots
        .checked_mul(2 * size_of_f32())
        .ok_or(TreeError::SizeOverflow)?;
    let touched_bytes = total_columns
        .div_ceil(64)
        .checked_mul(8)
        .ok_or(TreeError::SizeOverflow)?;
    let node_table_bytes = (node_count as u64)
        .checked_mul(24)
        .ok_or(TreeError::SizeOverflow)?;
    slot_bytes
        .checked_add(touched_bytes)
        .and_then(|value| value.checked_add(node_table_bytes))
        .and_then(|value| value.checked_add(2 * std::mem::size_of::<u64>() as u64))
        .ok_or(TreeError::SizeOverflow)
}

const fn size_of_f32() -> u64 {
    std::mem::size_of::<f32>() as u64
}

#[derive(Debug, thiserror::Error)]
pub enum TreeError {
    #[error("root state has no acting seat; nothing to enumerate")]
    RootIsTerminal,
    #[error("public betting tree exceeds the caller's {limit} decision-node checkpoint")]
    TooManyNodes { limit: usize },
    #[error("public betting tree exceeds the {limit}-action structural depth limit")]
    DepthLimit { limit: u32 },
    #[error("decision node for actor {actor} has no legal actions")]
    NoActions { actor: usize },
    #[error("public tree node {node} produced an empty action label")]
    EmptyActionLabel { node: NodeId },
    #[error("public tree node {node} produced a duplicate action label")]
    DuplicateActionLabel { node: NodeId },
    #[error("abstraction reported zero buckets for a reachable street")]
    ZeroBuckets,
    #[error("dense arena size overflowed while summing bucket/slot counts")]
    SizeOverflow,
    #[error(
        "dense arena exceeds the {limit} byte memory limit at a prefix of {node_count} nodes / \
         {total_columns} columns (at least {needed} bytes); reduce bucket counts or shrink the \
         betting tree"
    )]
    MemoryLimit {
        node_count: usize,
        total_columns: u64,
        limit: u64,
        needed: u64,
    },
    #[error("memory allocation failed for the complete {buffer} buffer ({requested_bytes} bytes)")]
    AllocationFailed {
        buffer: &'static str,
        requested_bytes: usize,
    },
    #[error("dense arena column id overflowed u32")]
    ColumnIdOverflow,
    #[error("bucket {bucket} is outside node {node}'s {count} buckets")]
    BucketOutOfRange {
        node: NodeId,
        bucket: BucketId,
        count: u32,
    },
    #[error("column {0} is outside the dense arena")]
    ColumnOutOfRange(u64),
    #[error("dense arena column action count does not match the caller's expectation")]
    ActionCountMismatch,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::abstraction::{
        BucketContext, BucketId, FeatureHashAbstraction, MultiwayAbstraction,
    };
    use crate::config::{AbstractionConfig, AnteConfig, BettingConfig, BlindConfig, SeatConfig};
    use crate::config::{MultiwayConfig, RakeConfig, UtilityConfig};
    use crate::holdem::HoldemGame;
    use crate::types::SeatId;

    fn smoke_config() -> MultiwayConfig {
        MultiwayConfig {
            seats: (0..3)
                .map(|_| SeatConfig {
                    name: None,
                    stack_bb: 10.0,
                    range: String::new(),
                    betting: None,
                })
                .collect(),
            button: SeatId(0),
            blinds: BlindConfig::default(),
            ante: AnteConfig::None,
            betting: BettingConfig::default(),
            forced_bets: None,
            abstraction: AbstractionConfig::default(),
        }
    }

    fn smoke_game() -> HoldemGame<FeatureHashAbstraction> {
        HoldemGame::new(
            &smoke_config(),
            &UtilityConfig::ChipEv,
            &RakeConfig::None,
            FeatureHashAbstraction::default(),
        )
        .unwrap()
    }

    #[test]
    fn impossible_policy_buffer_reservation_returns_a_typed_error() {
        assert!(matches!(
            try_zeroed_vec::<u8>(usize::MAX, "test-policy"),
            Err(TreeError::AllocationFailed {
                buffer: "test-policy",
                ..
            })
        ));
    }

    #[test]
    fn impossible_parallel_merge_reservation_returns_a_typed_error() {
        // The byte product fits usize, but exceeds Vec's isize::MAX bound.
        // This fails deterministically without requesting physical memory.
        let node_count = usize::MAX / std::mem::size_of::<TreeNode>();
        let expected_bytes = node_count * std::mem::size_of::<TreeNode>();
        assert!(matches!(
            reserve_parallel_merge_nodes(node_count),
            Err(TreeError::AllocationFailed {
                buffer: "parallel-tree-merge",
                requested_bytes,
            }) if requested_bytes == expected_bytes
        ));
    }

    #[test]
    fn parallel_fallback_releases_planning_states_before_serial_root() {
        use std::sync::Arc;

        #[derive(Clone)]
        struct TrackedState {
            depth: u8,
            branch: usize,
            lifetime: Arc<()>,
        }

        struct TrackedGame {
            lifetime: Arc<()>,
            root_calls: AtomicUsize,
        }

        impl ExternalSamplingGame for TrackedGame {
            type State = TrackedState;
            type Actions = (u8, usize);

            fn num_players(&self) -> usize {
                2
            }

            fn root_state(&self) -> Self::State {
                assert_eq!(
                    Arc::strong_count(&self.lifetime),
                    1,
                    "serial fallback retained states from the parallel attempt"
                );
                self.root_calls.fetch_add(1, Ordering::Relaxed);
                TrackedState {
                    depth: 0,
                    branch: 0,
                    lifetime: Arc::clone(&self.lifetime),
                }
            }

            fn actor(&self, state: &Self::State) -> Option<usize> {
                (state.depth < 2).then_some(0)
            }

            fn node_actions(&self, state: &Self::State) -> Self::Actions {
                (state.depth, state.branch)
            }

            fn num_actions_of(&self, _actions: &Self::Actions) -> usize {
                2
            }

            fn next_state_with(
                &self,
                state: &Self::State,
                _actions: &Self::Actions,
                action_index: usize,
            ) -> Self::State {
                TrackedState {
                    depth: state.depth + 1,
                    branch: action_index,
                    lifetime: Arc::clone(&state.lifetime),
                }
            }

            fn write_action_label(&self, actions: &Self::Actions, index: usize, out: &mut String) {
                // Fail while both children of the expanded root are still
                // retained in the plan. Serial enumeration must report the
                // first child's global node id, not the planner's local 0.
                if *actions != (1, 0) {
                    out.push(if index == 0 { 'a' } else { 'b' });
                }
            }

            fn bucket(
                &self,
                _state: &Self::State,
                _world: &crate::sampler::SampledWorld,
                _actor: usize,
            ) -> crate::solver::PrivateInfo {
                unreachable!("public enumeration does not inspect cards")
            }

            fn terminal_utilities(
                &self,
                _state: &Self::State,
                _world: &crate::sampler::SampledWorld,
                _utilities: &mut [f64],
            ) {
                unreachable!("public enumeration does not settle terminals")
            }

            fn dense_node_context(&self, _state: &Self::State) -> DenseNodeContext {
                DenseNodeContext {
                    street: Street::Preflop,
                    active_opponents: 1,
                    bucket_active_opponents: 1,
                }
            }
        }

        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(2)
            .build()
            .unwrap();
        for max_nodes in [0, MAX_TREE_NODES] {
            let game = TrackedGame {
                lifetime: Arc::new(()),
                root_calls: AtomicUsize::new(0),
            };
            let error = pool
                .install(|| enumerate_tree_with_limits_parallel(&game, max_nodes, 4))
                .unwrap_err();
            if max_nodes == 0 {
                // Resource error takes precedence over the planner's label
                // error when replayed in the canonical serial order.
                assert!(matches!(error, TreeError::TooManyNodes { limit: 0 }));
            } else {
                assert!(matches!(error, TreeError::EmptyActionLabel { node: 1 }));
            }
            assert_eq!(game.root_calls.load(Ordering::Relaxed), 2);
            assert_eq!(Arc::strong_count(&game.lifetime), 1);
        }
    }

    #[derive(Clone, Copy, Debug)]
    struct MaxBucketAbstraction;

    impl MultiwayAbstraction for MaxBucketAbstraction {
        fn num_buckets(&self, _street: Street, _active_opponents: u8) -> u32 {
            u32::MAX
        }

        fn bucket(&self, _context: BucketContext<'_>) -> BucketId {
            unreachable!("tree tests never evaluate cards")
        }

        fn fingerprint(&self) -> [u8; 32] {
            [0x42; 32]
        }
    }

    #[test]
    fn enumerated_tree_node_and_terminal_counts_are_stable() {
        let game = smoke_game();
        let tree = enumerate_tree(&game).unwrap();
        // Exact counts pin the enumeration; any change to the smoke config's
        // betting tree, or a bug in `enumerate_node`, moves these numbers.
        let terminal_count: usize = tree
            .nodes
            .iter()
            .flat_map(|node| node.children.iter())
            .filter(|child| matches!(child, Child::Terminal))
            .count();
        assert_eq!(tree.nodes.len(), 3_658);
        assert_eq!(terminal_count, 4_366);
        assert_eq!(tree.by_history.len(), tree.nodes.len());
        assert_eq!(tree.nodes[0].history, HistoryKey::ROOT);
        assert!(tree.nodes[0].parent.is_none());
    }

    #[test]
    fn ordered_parallel_enumeration_is_serial_exact_and_repeatable() {
        let game = smoke_game();
        let serial = enumerate_tree(&game).unwrap();
        for threads in [1, 2, 8] {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(threads)
                .build()
                .unwrap();
            let first = pool
                .install(|| enumerate_tree_with_limits_parallel(&game, MAX_TREE_NODES, u32::MAX))
                .unwrap();
            let second = pool
                .install(|| enumerate_tree_with_limits_parallel(&game, MAX_TREE_NODES, u32::MAX))
                .unwrap();
            assert_eq!(first, serial, "thread count {threads}");
            assert_eq!(second, first, "thread count {threads}");
        }
    }

    #[test]
    fn ordered_parallel_enumeration_preserves_limit_and_depth_errors() {
        let game = smoke_game();
        for threads in [2, 8] {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(threads)
                .build()
                .unwrap();
            let node_error = pool
                .install(|| enumerate_tree_with_limits_parallel(&game, 3_657, u32::MAX))
                .unwrap_err();
            assert!(matches!(
                node_error,
                TreeError::TooManyNodes { limit: 3_657 }
            ));

            let depth_error = pool
                .install(|| enumerate_tree_with_limits_parallel(&game, MAX_TREE_NODES, 0))
                .unwrap_err();
            assert!(matches!(depth_error, TreeError::DepthLimit { limit: 0 }));

            let exact = pool
                .install(|| enumerate_tree_with_limits_parallel(&game, 3_658, u32::MAX))
                .unwrap();
            assert_eq!(exact, enumerate_tree(&game).unwrap());
        }
    }

    #[test]
    fn configurable_node_limit_has_an_inclusive_decision_node_boundary() {
        let game = smoke_game();

        let zero_error = enumerate_tree_with_limit(&game, 0).unwrap_err();
        assert!(matches!(zero_error, TreeError::TooManyNodes { limit: 0 }));

        let below_error = enumerate_tree_with_limit(&game, 3_657).unwrap_err();
        assert!(matches!(
            below_error,
            TreeError::TooManyNodes { limit: 3_657 }
        ));

        let exact = enumerate_tree_with_limit(&game, 3_658).unwrap();
        let production = enumerate_tree(&game).unwrap();
        assert_eq!(exact.nodes.len(), 3_658);
        assert_eq!(exact.by_history, production.by_history);
        assert_eq!(
            exact
                .nodes
                .iter()
                .map(|node| (&node.history, &node.children))
                .collect::<Vec<_>>(),
            production
                .nodes
                .iter()
                .map(|node| (&node.history, &node.children))
                .collect::<Vec<_>>()
        );

        let above_hard_cap =
            enumerate_tree_with_limit(&game, MAX_TREE_NODES.saturating_add(1)).unwrap();
        assert_eq!(above_hard_cap.by_history, production.by_history);
    }

    #[test]
    fn arena_preflight_matches_manual_bucket_sum() {
        let game = smoke_game();
        let tree = enumerate_tree(&game).unwrap();
        let mut expected_columns = 0u64;
        let mut expected_slots = 0u64;
        for node in &tree.nodes {
            let buckets = u64::from(game.bucket_count(node.street, node.bucket_active_opponents));
            expected_columns += buckets;
            expected_slots += buckets * node.action_labels.len() as u64;
        }
        let arena = build_arena(&game, &tree, u64::MAX).unwrap();
        assert_eq!(arena.total_columns(), expected_columns);
        assert_eq!(arena.total_slots(), expected_slots);
        assert_eq!(arena.regrets.len() as u64, expected_slots);
        assert_eq!(arena.strategy_sum.len() as u64, expected_slots);
    }

    #[test]
    fn non_retaining_preflight_matches_materialized_arena() {
        let game = smoke_game();
        let measured = preflight_arena(&game, u64::MAX).unwrap();
        let tree = enumerate_tree(&game).unwrap();
        let arena = build_arena(&game, &tree, u64::MAX).unwrap();

        assert_eq!(measured.node_count, tree.nodes.len());
        assert_eq!(
            measured.terminal_edges,
            tree.nodes
                .iter()
                .flat_map(|node| node.children.iter())
                .filter(|child| matches!(child, Child::Terminal))
                .count() as u64
        );
        assert_eq!(measured.total_columns, arena.total_columns());
        assert_eq!(measured.total_slots, arena.total_slots());
        assert_eq!(measured.estimated_arena_bytes, arena.estimated_bytes());
    }

    #[test]
    fn non_retaining_preflight_node_checkpoint_is_inclusive() {
        let game = smoke_game();
        let error = preflight_arena_with_limits(&game, 3_657, u64::MAX).unwrap_err();
        assert!(matches!(error, TreeError::TooManyNodes { limit: 3_657 }));

        let measured = preflight_arena_with_limits(&game, 3_658, u64::MAX).unwrap();
        assert_eq!(measured.node_count, 3_658);
    }

    #[test]
    fn non_retaining_preflight_obeys_exact_byte_boundary() {
        let game = smoke_game();
        let complete = preflight_arena(&game, u64::MAX).unwrap();

        let equal = preflight_arena(&game, complete.estimated_arena_bytes).unwrap();
        assert_eq!(equal, complete);

        let error = preflight_arena(&game, complete.estimated_arena_bytes - 1).unwrap_err();
        let TreeError::MemoryLimit {
            node_count,
            total_columns,
            limit,
            needed,
        } = error
        else {
            panic!("expected exact byte-boundary failure");
        };
        assert_eq!(node_count, complete.node_count);
        assert_eq!(total_columns, complete.total_columns);
        assert_eq!(limit + 1, complete.estimated_arena_bytes);
        assert_eq!(needed, complete.estimated_arena_bytes);
    }

    #[test]
    fn production_depth_guard_fails_before_unbounded_recursion() {
        let game = smoke_game();
        assert!(matches!(
            preflight_arena_with_limits_and_depth(&game, MAX_TREE_NODES, u64::MAX, 0),
            Err(TreeError::DepthLimit { limit: 0 })
        ));
        assert!(matches!(
            enumerate_tree_with_limits(&game, MAX_TREE_NODES, 0),
            Err(TreeError::DepthLimit { limit: 0 })
        ));
    }

    #[test]
    fn dense_column_count_is_rejected_before_wire_id_overflow() {
        let game = HoldemGame::new(
            &smoke_config(),
            &UtilityConfig::ChipEv,
            &RakeConfig::None,
            MaxBucketAbstraction,
        )
        .unwrap();
        assert!(matches!(
            preflight_arena(&game, u64::MAX),
            Err(TreeError::ColumnIdOverflow)
        ));

        let tree = enumerate_tree(&game).unwrap();
        assert!(matches!(
            build_arena(&game, &tree, u64::MAX),
            Err(TreeError::ColumnIdOverflow)
        ));
    }

    #[test]
    fn non_retaining_preflight_stops_on_byte_boundary() {
        let game = smoke_game();
        let one_node = preflight_arena_with_limits(&game, MAX_TREE_NODES, u64::MAX)
            .unwrap()
            .estimated_arena_bytes;
        let error = preflight_arena_with_limits(&game, MAX_TREE_NODES, 1).unwrap_err();
        let TreeError::MemoryLimit {
            node_count,
            total_columns,
            limit,
            needed,
        } = error
        else {
            panic!("expected a byte-bounded preflight failure");
        };
        assert_eq!(node_count, 1);
        assert!(total_columns > 0);
        assert_eq!(limit, 1);
        assert!(needed > limit);
        assert!(one_node >= needed);
    }

    #[test]
    fn preflight_fails_before_allocating_when_memory_limit_is_tiny() {
        let game = smoke_game();
        let tree = enumerate_tree(&game).unwrap();
        let error = build_arena(&game, &tree, 1).unwrap_err();
        assert!(matches!(error, TreeError::MemoryLimit { .. }));
    }

    #[test]
    fn column_and_slot_addressing_round_trip() {
        let game = smoke_game();
        let tree = enumerate_tree(&game).unwrap();
        let arena = build_arena(&game, &tree, u64::MAX).unwrap();
        for (node_id, node) in tree.nodes.iter().enumerate() {
            let node_id = node_id as NodeId;
            let bucket_count = arena.bucket_count_of(node_id);
            for bucket in 0..bucket_count.min(5) {
                let column = arena.column_id(node_id, bucket).unwrap();
                let range = arena.slot_range(node_id, bucket).unwrap();
                assert_eq!(range.len(), node.action_labels.len());
                let resolved = arena
                    .slot_range_for_column(column, node.action_labels.len())
                    .unwrap();
                assert_eq!(resolved, range);
            }
        }
    }

    #[test]
    fn max_betting_players_threshold_shrinks_the_enumerated_tree() {
        // No special-casing is needed in this module: check-down thresholds
        // are entirely a `BettingState`/`HoldemGame` concern, so the public
        // tree simply enumerates whatever legal actions (and thus decision
        // nodes) the engine produces. This test is the regression guard that
        // a low threshold really does shrink the tree instead of silently
        // no-op'ing.
        let baseline_game = smoke_game();
        let baseline_tree = enumerate_tree(&baseline_game).unwrap();

        let mut capped_config = smoke_config();
        capped_config.betting.flop.max_betting_players = Some(1);
        capped_config.betting.turn.max_betting_players = Some(1);
        capped_config.betting.river.max_betting_players = Some(1);
        let capped_game = HoldemGame::new(
            &capped_config,
            &UtilityConfig::ChipEv,
            &RakeConfig::None,
            FeatureHashAbstraction::default(),
        )
        .unwrap();
        let capped_tree = enumerate_tree(&capped_game).unwrap();

        assert!(capped_tree.nodes.len() < baseline_tree.nodes.len());
        // A threshold of 1 checks down every postflop street: at least two
        // players always remain non-folded whenever a hand reaches the flop
        // (fewer would already be an uncontested terminal, not a decision
        // node), so no postflop decision node can survive.
        assert!(
            capped_tree
                .nodes
                .iter()
                .all(|node| node.street == Street::Preflop)
        );

        let baseline_arena = build_arena(&baseline_game, &baseline_tree, u64::MAX).unwrap();
        let capped_arena = build_arena(&capped_game, &capped_tree, u64::MAX).unwrap();
        assert!(capped_arena.node_count() < baseline_arena.node_count());
        assert!(capped_arena.total_columns() < baseline_arena.total_columns());
    }

    #[test]
    fn touched_bit_is_idempotent_and_counts_once() {
        let game = smoke_game();
        let tree = enumerate_tree(&game).unwrap();
        let mut arena = build_arena(&game, &tree, u64::MAX).unwrap();
        let column = arena.column_id(0, 0).unwrap();
        assert!(!arena.is_touched(column));
        assert!(arena.touched_set(column));
        assert!(arena.is_touched(column));
        assert!(!arena.touched_set(column));
        assert_eq!(arena.touched_count(), 1);
    }
}
