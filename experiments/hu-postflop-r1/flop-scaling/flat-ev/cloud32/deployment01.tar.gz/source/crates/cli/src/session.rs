//! Shared multiway session construction, factored out of
//! `multiway_solve::run_inner` so both the `solvers` CLI and (eventually) a
//! GUI worker build the exact same `MultiwaySolver` from a TOML config.
//!
//! This module intentionally stops short of anything CLI-specific: no
//! stdout printing, no `run.storage` restriction (the CLI still hard-rejects
//! non-f32 storage in `multiway_solve.rs`; the GUI is expected to support
//! `i16` later), and no checkpoint-cadence loop. It only builds the pieces a
//! caller needs to drive one: a ready-to-run `MultiwaySolver`, the run
//! parameters resolved from `[run]`, and the raw config text/hash to stamp
//! onto whatever artifact the caller eventually writes.

use std::path::{Path, PathBuf};
use std::time::Instant;

use abstraction::{Ehs2Abstraction, Ehs2Params};
use anyhow::{Context, Result, anyhow};
use formats::{
    Estimate, MULTIWAY_SCHEMA_VERSION, MultiwayHistoryNode, MultiwayMetricsRow,
    MultiwayPublicAction, MultiwayPublicState, MultiwaySeatMetrics, MultiwaySeatResult,
    MultiwaySolution, MultiwayStrategyBlock, MultiwayStrategyKey, MultiwayStrategyWeight,
};
use multiway::abstraction::{
    BucketContext, BucketId, MultiwayAbstraction, MultiwayAbstractionBackend,
    TableAbstractionAdapter, ehs2_table_fingerprint,
};
#[cfg(test)]
use multiway::abstraction::{FeatureHashAbstraction, FeatureHashParams};
use multiway::checkpoint::MultiwayCheckpoint;
use multiway::config::{
    AbstractionConfig, AbstractionKind, FieldPlayerConfig, RakeConfig as MultiwayRake, RecallMode,
    UtilityConfig as MultiwayUtility,
};
use multiway::solver::{DEFAULT_PRUNE_THRESHOLD, ProfileEvaluation, SolverConfig};
use multiway::{DealSampler, ExternalSamplingGame, HoldemGame, MultiwaySolver, Street};
use rayon::prelude::*;

use crate::config::{
    AlgorithmSection, GameSection, RakeSection, SolveConfig, StorageKind, UtilitySection,
};

const DEFAULT_MEMORY_LIMIT: u64 = 4 * 1024 * 1024 * 1024;

/// Resolved `run.stop_dev_gain`/`run.stop_confirmations`/
/// `run.stop_eval_period_secs` convergence stop rule; see
/// `crate::config::RunSection::stop_dev_gain` for the full semantics.
/// `None` in [`MultiwaySession::stop_rule`] means the rule is disabled and
/// `sweeps_target` is a plain target rather than a safety cap.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct StopRule {
    /// Threshold, in the run's own utility unit, compared against the
    /// maximum per-seat `deviation_gain_lower_bound` CI upper bound.
    pub dev_gain_threshold: f64,
    /// Consecutive passing evaluations required before stopping.
    pub confirmations: u32,
    /// Wall-clock period, in seconds, between stop-rule evaluations.
    pub eval_period_secs: f64,
    /// Best-response training traversals per seat per stop-rule evaluation
    /// (see `crate::config::RunSection::stop_br_traversals`). `0` disables
    /// the burst.
    pub br_traversals: u64,
}

/// Everything needed to run (or resume) a multiway solve: the constructed
/// solver plus the run parameters resolved from `[run]`.
/// How the run got its card abstraction, for the run's event log.
///
/// Building the EHS² tables takes minutes on a cold cache, so a watcher that
/// sees nothing during that time needs to be told why.
#[derive(Clone, Copy, Debug)]
pub struct AbstractionReady {
    pub cached: bool,
    pub secs: f64,
}

pub struct MultiwaySession {
    pub solver: MultiwaySolver<HoldemGame<MultiwayAbstractionBackend>>,
    /// `None` for a backend that needs no table (the test baseline).
    pub abstraction_ready: Option<AbstractionReady>,
    pub sweeps_target: u64,
    pub threads: usize,
    pub evaluation_cadence: u64,
    pub evaluation_samples: u64,
    pub evaluation_seed: u64,
    pub checkpoint_every: Option<u64>,
    pub storage: StorageKind,
    /// Convergence-based stop rule; see [`StopRule`]. `None` unless
    /// `run.stop_dev_gain` is set.
    pub stop_rule: Option<StopRule>,
    /// The exact config text this session was built from, unmodified.
    pub config_toml: String,
    /// Blake3 hash of `config_toml`'s raw bytes (see `formats::config_hash`).
    pub config_hash: [u8; 32],
    /// The multiway game config (seats, blinds, betting), kept around for
    /// display purposes (seat names/positions, button seat).
    pub game_config: multiway::MultiwayConfig,
    pub checkpoint_runtime: Option<multiway::checkpoint::CheckpointRuntimeState>,
    /// Evaluation-only common abstraction metadata. This is absent from
    /// ordinary solve/resume sessions and never contributes to checkpoint
    /// compatibility.
    pub deviation_reference: Option<DeviationReferenceMetadata>,
}

/// Identity and persistence location of an evaluation-only common
/// abstraction attached by [`build_multiway_session_with_deviation`].
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeviationReferenceMetadata {
    pub config_hash: [u8; 32],
    pub game_fingerprint: [u8; 32],
    /// Backend plus reference recall semantics, composed by the same helper
    /// used for a primary solver abstraction fingerprint.
    pub abstraction_fingerprint: [u8; 32],
    pub recall: RecallMode,
    pub artifact_cache: Option<PathBuf>,
}

/// Resource facts derived from the production public tree and configured
/// bucket counts without allocating the policy arena or building EHS² tables.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MultiwayResourcePreflight {
    pub complete: bool,
    pub recall: RecallMode,
    pub decision_nodes: u64,
    pub terminal_edges: Option<u64>,
    pub icm: Option<MultiwayIcmPreflight>,
    pub policy_columns: Option<u64>,
    pub policy_slots: Option<u64>,
    pub solver_state_bytes: Option<u64>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MultiwayIcmPreflight {
    pub field_players: u64,
    pub paid_places: u64,
    pub mode: IcmPreflightMode,
    pub samples: Option<u64>,
    pub seed: Option<u64>,
    pub prepared_bytes: Option<u64>,
    pub prepared_limit_bytes: Option<u64>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum IcmPreflightMode {
    Exact,
    Sampled,
}

struct ResourcePreflightAbstraction {
    config: AbstractionConfig,
}

impl MultiwayAbstraction for ResourcePreflightAbstraction {
    fn num_buckets(&self, street: Street, active_opponents: u8) -> u32 {
        if street == Street::Preflop {
            return cards::NUM_CLASSES as u32;
        }
        let profile = self.config.buckets_for(active_opponents);
        match street {
            Street::Preflop => unreachable!("preflop returned above"),
            Street::Flop => profile.map_or(u32::from(self.config.flop_buckets), |counts| {
                u32::from(counts.flop_buckets)
            }),
            Street::Turn => profile.map_or(u32::from(self.config.turn_buckets), |counts| {
                u32::from(counts.turn_buckets)
            }),
            Street::River => profile.map_or(u32::from(self.config.river_buckets), |counts| {
                u32::from(counts.river_buckets)
            }),
        }
    }

    fn bucket(&self, _context: BucketContext<'_>) -> BucketId {
        unreachable!("resource preflight never assigns physical hands to buckets")
    }

    fn fingerprint(&self) -> [u8; 32] {
        [0; 32]
    }
}

/// Runs the production contract, range/economics checks, and byte-bounded
/// non-retaining tree preflight behind `solvers validate --resources`.
///
/// The tree is walked without retaining nodes, so this reports the arena a
/// real solve would need without allocating it or building EHS² tables.
pub fn preflight_multiway_config(raw_toml: &str) -> Result<MultiwayResourcePreflight> {
    crate::multiway_v1::validate_production_contract(raw_toml)
        .context("validating production Multiway Preflop contract")?;
    let config =
        crate::config::parse_internal_config(raw_toml).context("parsing config for preflight")?;
    let SolveConfig {
        game,
        rake,
        utility,
        run,
        ..
    } = config;
    let GameSection::PreflopMultiway(game_config) = game else {
        return Err(anyhow!(
            "multiway resource preflight requires kind = \"preflop-multiway\""
        ));
    };

    let utility = convert_utility(utility)?;
    let rake = convert_rake(rake);
    game_config
        .validate_economics(&utility, &rake)
        .context("validating multiway game and utility for preflight")?;
    let icm = match &utility {
        MultiwayUtility::ChipEv => None,
        MultiwayUtility::TournamentIcm {
            outside_field,
            payouts,
            samples,
            seed,
        } => {
            let field_players = game_config
                .seats
                .len()
                .checked_add(outside_field.len())
                .context("counting ICM field players")?;
            let paid_places = payouts
                .iter()
                .rposition(|payout| *payout != 0.0)
                .map_or(0, |place| place + 1);
            if field_players <= multiway::icm::EXACT_ICM_MAX_PLAYERS {
                Some(MultiwayIcmPreflight {
                    field_players: field_players as u64,
                    paid_places: paid_places as u64,
                    mode: IcmPreflightMode::Exact,
                    samples: None,
                    seed: None,
                    prepared_bytes: None,
                    prepared_limit_bytes: None,
                })
            } else {
                let prepared_bytes = multiway::icm::prepared_race_memory_bytes(
                    game_config.seats.len(),
                    outside_field.len(),
                    paid_places,
                    *samples,
                )
                .context("sizing sampled ICM preparation buffers")?;
                Some(MultiwayIcmPreflight {
                    field_players: field_players as u64,
                    paid_places: paid_places as u64,
                    mode: IcmPreflightMode::Sampled,
                    samples: Some(*samples),
                    seed: Some(*seed),
                    prepared_bytes: Some(prepared_bytes as u64),
                    prepared_limit_bytes: Some(multiway::icm::MAX_PREPARED_RACE_BYTES as u64),
                })
            }
        }
    };

    let recall = game_config.abstraction.recall;
    let abstraction = ResourcePreflightAbstraction {
        config: game_config.abstraction.clone(),
    };
    let game = HoldemGame::new(
        &game_config,
        &MultiwayUtility::ChipEv,
        &MultiwayRake::None,
        abstraction,
    )
    .context("building public multiway game for preflight")?;
    let _sampler = game
        .deal_sampler()
        .context("compiling table ranges for preflight")?;
    let memory_limit = run
        .max_memory_bytes
        .filter(|bytes| *bytes != u64::MAX)
        .unwrap_or(crate::multiway_v1::PRODUCTION_POLICY_ARENA_AUTO_BYTES);
    let arena = match multiway::tree::preflight_arena(&game, memory_limit) {
        Ok(arena) => arena,
        Err(multiway::tree::TreeError::MemoryLimit {
            node_count,
            total_columns,
            needed,
            ..
        }) => {
            return Ok(MultiwayResourcePreflight {
                complete: false,
                recall,
                decision_nodes: node_count as u64,
                terminal_edges: None,
                icm,
                policy_columns: Some(total_columns),
                policy_slots: None,
                solver_state_bytes: Some(needed),
            });
        }
        Err(error) => {
            return Err(error).context("counting public tree and sizing the policy arena");
        }
    };

    Ok(MultiwayResourcePreflight {
        complete: true,
        recall,
        decision_nodes: arena.node_count as u64,
        terminal_edges: Some(arena.terminal_edges),
        icm,
        policy_columns: Some(arena.total_columns),
        policy_slots: Some(arena.total_slots),
        solver_state_bytes: Some(arena.estimated_arena_bytes),
    })
}

/// Default [`StopRule::confirmations`] and [`StopRule::eval_period_secs`]
/// when `run.stop_dev_gain` is set but the corresponding key is omitted.
const DEFAULT_STOP_CONFIRMATIONS: u32 = 2;
const DEFAULT_STOP_EVAL_PERIOD_SECS: f64 = 30.0;
/// Default [`StopRule::br_traversals`] when `run.stop_dev_gain` is set but
/// `run.stop_br_traversals` is omitted.
const DEFAULT_STOP_BR_TRAVERSALS: u64 = 2_000;

/// Parses `raw_toml`, validates it as a `kind = "preflop-multiway"` config,
/// and builds a ready-to-run (or ready-to-resume) [`MultiwaySession`].
///
/// `resume_checkpoint`, when `Some`, restores solver state from a
/// `.mwckpt` file (always f32 internally, regardless of `run.storage`) and
/// verifies its configuration/abstraction fingerprints match this config
/// before returning.
/// Test-only session builder. It swaps the configured EHS² percentile table
/// for the cheap deterministic feature-hash baseline, because building a real
/// EHS² table costs minutes and these tests exercise session wiring rather
/// than bucket quality. Production code paths use
/// [`build_production_multiway_session`].
#[cfg(test)]
pub(crate) fn build_multiway_session(
    raw_toml: &str,
    resume_checkpoint: Option<&Path>,
) -> Result<MultiwaySession> {
    build_multiway_session_internal(
        raw_toml,
        None,
        resume_checkpoint,
        SessionStoragePolicy::Compatibility,
        AbstractionPolicy::CheapBaseline,
    )
}

/// Production solve/resume constructor. It accepts only the fixed
/// EHS2/current-street contract and returns only after the complete policy
/// arena has been allocated and page-committed.
pub fn build_production_multiway_session(
    raw_toml: &str,
    resume_checkpoint: Option<&Path>,
) -> Result<MultiwaySession> {
    build_multiway_session_internal(
        raw_toml,
        None,
        resume_checkpoint,
        SessionStoragePolicy::PreallocatedProduction,
        AbstractionPolicy::Configured,
    )
}

/// A one-shot research session using an abstraction supplied by a
/// feature-gated caller.  The normal production builder remains the only
/// route used by `solvers solve`; this type exists so research examples can
/// compare an alternative abstraction without making it a config-selectable
/// production backend.
///
/// Construction does not drive the production run loop. The research caller
/// supplies its own sweep/evaluation limits and external timeout; the returned
/// run settings are descriptive and do not schedule stops or artifacts.
#[cfg(feature = "research-draw-abstraction")]
pub struct ResearchMultiwaySession<A: MultiwayAbstraction> {
    pub solver: MultiwaySolver<HoldemGame<A>>,
    pub sweeps_target: u64,
    pub threads: usize,
    pub evaluation_cadence: u64,
    pub evaluation_samples: u64,
    pub evaluation_seed: u64,
    pub storage: StorageKind,
    pub stop_rule: Option<StopRule>,
    pub config_toml: String,
    pub config_hash: [u8; 32],
    pub game_config: multiway::MultiwayConfig,
}

/// Builds a research-only, preallocated multiway session around an already
/// constructed abstraction.  The supplied abstraction is checked against the
/// v1 config's effective bucket contract for every active-opponent count before
/// the policy arena is allocated.  Checkpoints and deviation abstractions are
/// intentionally unavailable here: callers must construct a fresh session
/// for each research arm.
#[cfg(feature = "research-draw-abstraction")]
pub fn build_research_multiway_session<A: MultiwayAbstraction>(
    raw_toml: &str,
    abstraction: A,
) -> Result<ResearchMultiwaySession<A>> {
    let config: SolveConfig =
        crate::config::parse_internal_config(raw_toml).context("parsing research config")?;
    let SolveConfig {
        schema: _,
        game,
        rake,
        utility,
        algorithm,
        run,
    } = config;
    let GameSection::PreflopMultiway(game_config) = game else {
        return Err(anyhow!(
            "research multiway session requires kind = \"preflop-multiway\""
        ));
    };
    validate_production_abstraction(&game_config)?;
    if run.target_nash_conv.is_some() {
        return Err(anyhow!(
            "multiway profiles do not expose NashConv; remove run.target_nash_conv"
        ));
    }
    let utility = convert_utility(utility)?;
    let rake = convert_rake(rake);
    game_config
        .validate_economics(&utility, &rake)
        .context("validating research multiway game and utility")?;

    let preflop_buckets = cards::NUM_CLASSES as u32;
    if preflop_buckets != 169 {
        return Err(anyhow!(
            "research abstraction contract requires 169 preflop classes"
        ));
    }
    for active_opponents in 0..=8 {
        let expected = [
            (Street::Preflop, preflop_buckets),
            (
                Street::Flop,
                u32::from(game_config.abstraction.flop_buckets),
            ),
            (
                Street::Turn,
                u32::from(game_config.abstraction.turn_buckets),
            ),
            (
                Street::River,
                u32::from(game_config.abstraction.river_buckets),
            ),
        ];
        for (street, count) in expected {
            if count == 0 {
                return Err(anyhow!(
                    "research abstraction contract has zero buckets for {street:?}"
                ));
            }
            let actual = abstraction.num_buckets(street, active_opponents);
            if actual != count {
                return Err(anyhow!(
                    "research abstraction bucket mismatch for {street:?}, active_opponents={active_opponents}: expected {count}, got {actual}"
                ));
            }
        }
    }
    let abstraction_fingerprint = abstraction.fingerprint();
    if abstraction_fingerprint == [0; 32] {
        return Err(anyhow!(
            "research abstraction must provide a non-zero fingerprint"
        ));
    }

    let game = HoldemGame::new(&game_config, &utility, &rake, abstraction)
        .context("building research multiway game")?;
    let game_fingerprint = game.game_fingerprint();
    if abstraction_fingerprint == game_fingerprint {
        return Err(anyhow!(
            "research abstraction fingerprint must be distinct from game fingerprint"
        ));
    }
    let sampler = game.deal_sampler().context("compiling table ranges")?;

    let (
        algorithm_seed,
        exploration_epsilon,
        discount_every,
        discount_until,
        traverser_vector,
        prune,
        prune_threshold_override,
        prune_skip_probability,
    ) = match algorithm {
        AlgorithmSection::ExternalSamplingMccfr {
            seed,
            exploration_epsilon,
            discount_every,
            discount_until,
            traverser_vector,
            prune,
            prune_threshold,
            prune_skip_probability,
        } => (
            seed,
            exploration_epsilon,
            discount_every,
            discount_until,
            traverser_vector,
            prune,
            prune_threshold,
            prune_skip_probability,
        ),
        _ => {
            return Err(anyhow!(
                "preflop-multiway requires schedule = \"external-sampling-mccfr\""
            ));
        }
    };
    if prune && !traverser_vector {
        return Err(anyhow!(
            "algorithm.prune requires algorithm.traverser_vector = true"
        ));
    }
    if let Some(threshold) = prune_threshold_override
        && (!threshold.is_finite() || threshold >= 0.0)
    {
        return Err(anyhow!(
            "algorithm.prune_threshold must be finite and strictly negative, found {threshold}"
        ));
    }
    let sweeps = run.sweeps.unwrap_or(run.iterations);
    if sweeps == 0 {
        return Err(anyhow!("run.sweeps must be positive for a multiway solve"));
    }
    let evaluation_cadence = run.evaluation_cadence.unwrap_or(run.check_every);
    if evaluation_cadence == 0 {
        return Err(anyhow!("run.evaluation_cadence must be positive"));
    }
    if run.checkpoint_every.is_some() {
        return Err(anyhow!(
            "research sessions are one-shot and do not support checkpoint_every"
        ));
    }
    let threads = run.threads.unwrap_or_else(rayon::current_num_threads);
    if threads == 0 {
        return Err(anyhow!("run.threads must be positive"));
    }
    if run.evaluation_samples == Some(0) {
        return Err(anyhow!(
            "run.evaluation_samples must be positive when supplied"
        ));
    }
    if run.sweep_batch == Some(0) {
        return Err(anyhow!("run.sweep_batch must be positive when supplied"));
    }
    if run
        .stop_dev_gain
        .is_some_and(|threshold| !threshold.is_finite() || threshold <= 0.0)
    {
        return Err(anyhow!(
            "run.stop_dev_gain must be finite and positive when supplied"
        ));
    }
    if run.stop_confirmations == Some(0) {
        return Err(anyhow!(
            "run.stop_confirmations must be positive when supplied"
        ));
    }
    if run
        .stop_eval_period_secs
        .is_some_and(|period| !period.is_finite() || period <= 0.0)
    {
        return Err(anyhow!(
            "run.stop_eval_period_secs must be finite and positive when supplied"
        ));
    }
    let stop_rule = run.stop_dev_gain.map(|dev_gain_threshold| StopRule {
        dev_gain_threshold,
        confirmations: run.stop_confirmations.unwrap_or(DEFAULT_STOP_CONFIRMATIONS),
        eval_period_secs: run
            .stop_eval_period_secs
            .unwrap_or(DEFAULT_STOP_EVAL_PERIOD_SECS),
        br_traversals: run.stop_br_traversals.unwrap_or(DEFAULT_STOP_BR_TRAVERSALS),
    });
    let evaluation_samples = run.evaluation_samples.unwrap_or(256);
    let prune_threshold = if !prune {
        DEFAULT_PRUNE_THRESHOLD
    } else {
        prune_threshold_override.unwrap_or_else(|| derive_prune_threshold(&utility, &game_config))
    };
    let max_memory_bytes = resolve_policy_memory_limit(
        SessionStoragePolicy::PreallocatedProduction,
        run.max_memory_bytes,
    )?;
    let solver_config = SolverConfig {
        seed: run.seed.unwrap_or(algorithm_seed),
        max_memory_bytes,
        max_traversal_depth: 512,
        exploration_epsilon,
        discount_every,
        discount_until,
        sweep_batch: run.sweep_batch.unwrap_or(1),
        traverser_vector,
        prune,
        prune_threshold,
        prune_skip_probability,
    };
    let evaluation_seed = solver_config.seed ^ 0x6576_616c_7561_7465;
    let solver =
        MultiwaySolver::new_preallocated_with_threads(game, sampler, solver_config, threads)
            .context("initializing research multiway MCCFR")?;
    let allocation = solver
        .policy_arena_allocation()
        .ok_or_else(|| anyhow!("research solver returned without a preallocated policy arena"))?;
    if !allocation.pages_committed {
        return Err(anyhow!(
            "research solver returned before policy arena pages were committed"
        ));
    }

    Ok(ResearchMultiwaySession {
        solver,
        sweeps_target: sweeps,
        threads,
        evaluation_cadence,
        evaluation_samples,
        evaluation_seed,
        storage: run.storage,
        stop_rule,
        config_toml: raw_toml.to_string(),
        config_hash: formats::config_hash(raw_toml.as_bytes()),
        game_config,
    })
}

/// Builds a candidate session with a separately configured common
/// abstraction used only for deviator training/evaluation.
///
/// The reference's public game, ranges, rake, and utility must have the exact
/// same game fingerprint as the candidate. Its algorithm/run sections are not
/// used. The reference is attached before checkpoint restore; core
/// fingerprints intentionally continue to describe only the candidate.
#[cfg(test)]
pub(crate) fn build_multiway_session_with_deviation(
    raw_toml: &str,
    deviation_raw_toml: &str,
    resume_checkpoint: Option<&Path>,
) -> Result<MultiwaySession> {
    build_multiway_session_internal(
        raw_toml,
        Some(deviation_raw_toml),
        resume_checkpoint,
        SessionStoragePolicy::Compatibility,
        AbstractionPolicy::CheapBaseline,
    )
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SessionStoragePolicy {
    /// Sparse storage, reachable only from the test-only session builders.
    #[cfg(test)]
    Compatibility,
    PreallocatedProduction,
}

/// Which card abstraction a session build should use.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AbstractionPolicy {
    /// Build what the config selects. The only production choice.
    Configured,
    /// Substitute the cheap feature-hash baseline.
    #[cfg(test)]
    CheapBaseline,
}

fn build_multiway_session_internal(
    raw_toml: &str,
    deviation_raw_toml: Option<&str>,
    resume_checkpoint: Option<&Path>,
    storage_policy: SessionStoragePolicy,
    abstraction_policy: AbstractionPolicy,
) -> Result<MultiwaySession> {
    let config: SolveConfig =
        crate::config::parse_internal_config(raw_toml).context("parsing config")?;
    let SolveConfig {
        schema: _,
        game,
        rake,
        utility,
        algorithm,
        run,
    } = config;
    let GameSection::PreflopMultiway(game_config) = game else {
        return Err(anyhow!(
            "multiway solve path requires kind = \"preflop-multiway\""
        ));
    };
    if matches!(storage_policy, SessionStoragePolicy::PreallocatedProduction) {
        validate_production_abstraction(&game_config)?;
        if deviation_raw_toml.is_some() {
            return Err(anyhow!(
                "production sessions do not accept a separately configured deviation abstraction"
            ));
        }
    }
    if run.target_nash_conv.is_some() {
        return Err(anyhow!(
            "multiway profiles do not expose NashConv; remove run.target_nash_conv"
        ));
    }
    let utility = convert_utility(utility)?;
    let rake = convert_rake(rake);
    let (mut game, sampler, abstraction_ready) =
        build_multiway_game_from_config(&game_config, &utility, &rake, abstraction_policy)?;
    let mut deviation_reference = deviation_raw_toml
        .map(|raw| build_deviation_reference(raw, game.game_fingerprint(), abstraction_policy))
        .transpose()
        .context("building common deviation reference")?;
    if let Some(reference) = deviation_reference.as_mut() {
        let recall = reference.metadata.recall;
        game = game.with_deviation_abstraction(reference.backend(), recall);
    }

    let (
        algorithm_seed,
        exploration_epsilon,
        discount_every,
        discount_until,
        traverser_vector,
        prune,
        prune_threshold_override,
        prune_skip_probability,
    ) = match algorithm {
        AlgorithmSection::ExternalSamplingMccfr {
            seed,
            exploration_epsilon,
            discount_every,
            discount_until,
            traverser_vector,
            prune,
            prune_threshold,
            prune_skip_probability,
        } => (
            seed,
            exploration_epsilon,
            discount_every,
            discount_until,
            traverser_vector,
            prune,
            prune_threshold,
            prune_skip_probability,
        ),
        _ => {
            return Err(anyhow!(
                "preflop-multiway requires schedule = \"external-sampling-mccfr\""
            ));
        }
    };
    if prune && !traverser_vector {
        return Err(anyhow!(
            "algorithm.prune requires algorithm.traverser_vector = true"
        ));
    }
    if let Some(threshold) = prune_threshold_override
        && (!threshold.is_finite() || threshold >= 0.0)
    {
        return Err(anyhow!(
            "algorithm.prune_threshold must be finite and strictly negative, found {threshold}"
        ));
    }
    let sweeps = run.sweeps.unwrap_or(run.iterations);
    if sweeps == 0 {
        return Err(anyhow!("run.sweeps must be positive for a multiway solve"));
    }
    let evaluation_cadence = run.evaluation_cadence.unwrap_or(run.check_every);
    if evaluation_cadence == 0 {
        return Err(anyhow!("run.evaluation_cadence must be positive"));
    }
    if run.checkpoint_every == Some(0) {
        return Err(anyhow!(
            "run.checkpoint_every must be positive when supplied"
        ));
    }
    let threads = run.threads.unwrap_or_else(rayon::current_num_threads);
    if threads == 0 {
        return Err(anyhow!("run.threads must be positive"));
    }
    if run.evaluation_samples == Some(0) {
        return Err(anyhow!(
            "run.evaluation_samples must be positive when supplied"
        ));
    }
    if run.sweep_batch == Some(0) {
        return Err(anyhow!("run.sweep_batch must be positive when supplied"));
    }
    if run
        .stop_dev_gain
        .is_some_and(|threshold| !threshold.is_finite() || threshold <= 0.0)
    {
        return Err(anyhow!(
            "run.stop_dev_gain must be finite and positive when supplied"
        ));
    }
    if run.stop_confirmations == Some(0) {
        return Err(anyhow!(
            "run.stop_confirmations must be positive when supplied"
        ));
    }
    if run
        .stop_eval_period_secs
        .is_some_and(|period| !period.is_finite() || period <= 0.0)
    {
        return Err(anyhow!(
            "run.stop_eval_period_secs must be finite and positive when supplied"
        ));
    }
    let stop_rule = run.stop_dev_gain.map(|dev_gain_threshold| StopRule {
        dev_gain_threshold,
        confirmations: run.stop_confirmations.unwrap_or(DEFAULT_STOP_CONFIRMATIONS),
        eval_period_secs: run
            .stop_eval_period_secs
            .unwrap_or(DEFAULT_STOP_EVAL_PERIOD_SECS),
        br_traversals: run.stop_br_traversals.unwrap_or(DEFAULT_STOP_BR_TRAVERSALS),
    });

    let evaluation_samples = run.evaluation_samples.unwrap_or(256);
    let prune_threshold = if !prune {
        // Ignored by the engine when `prune` is false; keep the documented
        // default so a disabled-pruning solver config is still valid input.
        DEFAULT_PRUNE_THRESHOLD
    } else {
        prune_threshold_override.unwrap_or_else(|| derive_prune_threshold(&utility, &game_config))
    };
    let max_memory_bytes = resolve_policy_memory_limit(storage_policy, run.max_memory_bytes)?;
    let solver_config = SolverConfig {
        seed: run.seed.unwrap_or(algorithm_seed),
        max_memory_bytes,
        max_traversal_depth: 512,
        exploration_epsilon,
        discount_every,
        discount_until,
        sweep_batch: run.sweep_batch.unwrap_or(1),
        traverser_vector,
        prune,
        prune_threshold,
        prune_skip_probability,
    };
    let evaluation_seed = solver_config.seed ^ 0x6576_616c_7561_7465;

    let mut checkpoint_runtime = None;
    let solver = if let Some(path) = resume_checkpoint {
        let expected_configuration =
            multiway::solver::configuration_fingerprint_for_setup(&game, &sampler, solver_config);
        let expected_abstraction = multiway::abstraction_fingerprint_with_recall(
            game.abstraction_fingerprint(),
            game.recall_mode(),
        );
        let checkpoint =
            MultiwayCheckpoint::load(path, expected_configuration, expected_abstraction)
                .with_context(|| format!("reading multiway checkpoint {}", path.display()))?;
        checkpoint_runtime = checkpoint.config_toml.as_ref().map(|_| checkpoint.runtime);
        let solver = match storage_policy {
            #[cfg(test)]
            SessionStoragePolicy::Compatibility => MultiwaySolver::from_state_with_config(
                game,
                sampler,
                checkpoint.state,
                solver_config,
            ),
            SessionStoragePolicy::PreallocatedProduction => {
                MultiwaySolver::from_state_with_config_preallocated_with_threads(
                    game,
                    sampler,
                    checkpoint.state,
                    solver_config,
                    threads,
                )
            }
        }
        .context("restoring multiway MCCFR state")?;
        if solver.configuration_fingerprint() != checkpoint.header.configuration_fingerprint {
            return Err(anyhow!(
                "checkpoint belongs to different table rules or ranges"
            ));
        }
        if solver.abstraction_fingerprint() != checkpoint.header.abstraction_fingerprint {
            return Err(anyhow!(
                "checkpoint belongs to a different card abstraction"
            ));
        }
        solver
    } else {
        match storage_policy {
            #[cfg(test)]
            SessionStoragePolicy::Compatibility => {
                MultiwaySolver::new(game, sampler, solver_config)
            }
            SessionStoragePolicy::PreallocatedProduction => {
                MultiwaySolver::new_preallocated_with_threads(game, sampler, solver_config, threads)
            }
        }
        .context("initializing multiway MCCFR")?
    };

    if matches!(storage_policy, SessionStoragePolicy::PreallocatedProduction) {
        let allocation = solver.policy_arena_allocation().ok_or_else(|| {
            anyhow!("production solver returned without a preallocated policy arena")
        })?;
        if !allocation.pages_committed {
            return Err(anyhow!(
                "production solver returned before policy arena pages were committed"
            ));
        }
    }

    if solver.metrics().sweeps > sweeps {
        return Err(anyhow!(
            "checkpoint already contains {} sweeps, exceeding target {}",
            solver.metrics().sweeps,
            sweeps
        ));
    }

    Ok(MultiwaySession {
        solver,
        abstraction_ready,
        sweeps_target: sweeps,
        threads,
        evaluation_cadence,
        evaluation_samples,
        evaluation_seed,
        checkpoint_every: run.checkpoint_every,
        storage: run.storage,
        stop_rule,
        config_toml: raw_toml.to_string(),
        config_hash: formats::config_hash(raw_toml.as_bytes()),
        game_config,
        checkpoint_runtime,
        deviation_reference: deviation_reference.map(|reference| reference.metadata),
    })
}

fn resolve_policy_memory_limit(
    storage_policy: SessionStoragePolicy,
    configured: Option<u64>,
) -> Result<u64> {
    if !matches!(storage_policy, SessionStoragePolicy::PreallocatedProduction) {
        return Ok(configured.unwrap_or(DEFAULT_MEMORY_LIMIT));
    }
    let resolved = match configured {
        None | Some(u64::MAX) => crate::multiway_v1::PRODUCTION_POLICY_ARENA_AUTO_BYTES,
        Some(bytes) => bytes,
    };
    Ok(resolved)
}

fn validate_production_abstraction(game: &multiway::MultiwayConfig) -> Result<()> {
    if !matches!(game.abstraction.kind, AbstractionKind::Ehs2Table) {
        return Err(anyhow!(
            "MWP001: rollout-kmeans was removed from production because its assignment cache \
             grows during Solve; use canonical v1 kind = \"ehs2-percentile\""
        ));
    }
    if !matches!(game.abstraction.recall, RecallMode::Street) {
        return Err(anyhow!(
            "MWP002: full/bucket-history recall was removed from production because sparse \
             policy memory grows during Solve; production requires current-street preallocation"
        ));
    }
    if !game.abstraction.active_opponent_buckets.is_empty() {
        return Err(anyhow!(
            "MWP001: active-opponent bucket overrides are rollout-only and unavailable in production"
        ));
    }
    Ok(())
}

struct BuiltDeviationReference {
    backend: Option<MultiwayAbstractionBackend>,
    metadata: DeviationReferenceMetadata,
}

impl BuiltDeviationReference {
    fn backend(&mut self) -> MultiwayAbstractionBackend {
        self.backend
            .take()
            .expect("reference backend is moved into the candidate exactly once")
    }
}

fn build_deviation_reference(
    raw_toml: &str,
    candidate_game_fingerprint: [u8; 32],
    abstraction_policy: AbstractionPolicy,
) -> Result<BuiltDeviationReference> {
    let config: SolveConfig =
        crate::config::parse_internal_config(raw_toml).context("parsing reference config")?;
    let SolveConfig {
        schema: _,
        game,
        rake,
        utility,
        algorithm: _,
        run: _,
    } = config;
    let GameSection::PreflopMultiway(game_config) = game else {
        return Err(anyhow!(
            "common deviation reference requires kind = \"preflop-multiway\""
        ));
    };
    let utility = convert_utility(utility)?;
    let rake = convert_rake(rake);
    let (reference_game, _, _) =
        build_multiway_game_from_config(&game_config, &utility, &rake, abstraction_policy)?;
    let reference_game_fingerprint = reference_game.game_fingerprint();
    if candidate_game_fingerprint != reference_game_fingerprint {
        return Err(anyhow!(
            "candidate/reference game fingerprint mismatch: candidate={}, reference={}",
            formats::config_hash_hex(&candidate_game_fingerprint),
            formats::config_hash_hex(&reference_game_fingerprint)
        ));
    }
    let recall = game_config.abstraction.recall;
    let abstraction_fingerprint = multiway::abstraction_fingerprint_with_recall(
        reference_game.abstraction_fingerprint(),
        recall,
    );
    Ok(BuiltDeviationReference {
        backend: Some(reference_game.into_abstraction()),
        metadata: DeviationReferenceMetadata {
            config_hash: formats::config_hash(raw_toml.as_bytes()),
            game_fingerprint: reference_game_fingerprint,
            abstraction_fingerprint,
            recall,
            artifact_cache: game_config.abstraction.artifact_cache,
        },
    })
}

/// Scale factor `derive_prune_threshold` applies to the game's total stakes
/// to get `algorithm.prune_threshold` when the key is omitted. See
/// `derive_prune_threshold`'s doc comment for its calibration boundary.
pub(crate) const PRUNE_THRESHOLD_STAKE_FACTOR: f64 = -10.0;

/// Derives `algorithm.prune_threshold` when `algorithm.prune = true` but the
/// key itself is omitted, from the game's stakes: `-10.0 *` the total
/// starting stacks (in bb) for `[utility] kind = "chip-ev"`, or `-10.0 *`
/// the total payouts for `kind = "tournament-icm"`.
///
/// This scale was originally calibrated with solver-state version 2's
/// within-bucket-normalized range-vector regret updates. Version 3 instead
/// normalizes over the full feasible own range, so each bucket's increment
/// also carries its conditional feasible mass (roughly 1/169 for a uniform
/// preflop range, with class-size and blocker variation). The old activation
/// timing does not validate this threshold under the current estimator.
/// Compare paired pruned and unpruned runs before drawing speed or quality
/// conclusions. The 5% unpruned revisit probability provides opportunities
/// to revisit skipped pairs; periodic discount moves negative regrets toward
/// zero and can delay or reverse pruning eligibility.
fn derive_prune_threshold(
    utility: &MultiwayUtility,
    game_config: &multiway::MultiwayConfig,
) -> f64 {
    let total = match utility {
        MultiwayUtility::ChipEv => game_config
            .seats
            .iter()
            .map(|seat| seat.stack_bb)
            .sum::<f64>(),
        MultiwayUtility::TournamentIcm { payouts, .. } => payouts.iter().sum::<f64>(),
    };
    PRUNE_THRESHOLD_STAKE_FACTOR * total
}

/// Hard cap on the adaptive stop-rule evaluation sample count: matches the
/// ladder cap documented on `run.stop_dev_gain`, enforced by the CLI drive
/// loop (`multiway_solve::run_inner`) via [`run_stop_rule_check`].
pub(crate) const MAX_STOP_RULE_SAMPLES: u64 = 65_536;

/// Mutable state of the wall-clock convergence stop rule (`run.stop_dev_gain`)
/// across one run, threaded through repeated [`run_stop_rule_check`] calls.
pub struct StopRuleState {
    /// Adaptive evaluation sample count: starts at the session's
    /// `evaluation_samples` and doubles (capped at [`MAX_STOP_RULE_SAMPLES`])
    /// whenever a check's CI is too wide to ever settle below the threshold.
    pub samples: u64,
    /// Consecutive passing evaluations so far.
    pub confirmations_met: u32,
    /// Wall clock of the last stop-rule check; the caller compares this
    /// against `StopRule::eval_period_secs` to decide whether to call
    /// [`run_stop_rule_check`] again.
    pub last_eval: Instant,
    /// Monotonically increasing index of the next check, folded into the
    /// training and held-out evaluation seeds. Persisted in checkpoints so
    /// resumed checks continue with fresh batches instead of reusing evidence.
    pub eval_index: u64,
}

impl StopRuleState {
    pub fn new(initial_samples: u64) -> Self {
        Self {
            samples: initial_samples,
            confirmations_met: 0,
            last_eval: Instant::now(),
            eval_index: 0,
        }
    }
}

/// Trains one burst deviator per seat in parallel, on a deterministic worker
/// pool sized to `threads` rather than relying on rayon's ambient global
/// pool (whose thread count the config doesn't control). Shared by every
/// caller that trains a per-seat best-response burst: the stop-rule check
/// below, and `mw_eval`'s purification sweep.
pub fn train_deviators_parallel(
    solver: &MultiwaySolver<HoldemGame<MultiwayAbstractionBackend>>,
    num_players: usize,
    threads: usize,
    traversals: u64,
    seed: u64,
    variant: multiway::ProfileVariant,
) -> Result<Vec<multiway::DeviatorPolicy>> {
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(threads)
        .build()
        .map_err(|error| anyhow!("building deviator training thread pool: {error}"))?;
    pool.install(|| {
        (0..num_players)
            .into_par_iter()
            .map(|seat| solver.train_deviator(seat, traversals, seed, variant))
            .collect::<std::result::Result<Vec<_>, _>>()
    })
    .map_err(|error| anyhow!("training deviator: {error}"))
}

/// Reference-evaluation counterpart to [`train_deviators_parallel`] that
/// retains each seat's training coverage report.
pub fn train_deviators_with_reports_parallel(
    solver: &MultiwaySolver<HoldemGame<MultiwayAbstractionBackend>>,
    num_players: usize,
    threads: usize,
    traversals: u64,
    seed: u64,
    variant: multiway::ProfileVariant,
) -> Result<Vec<multiway::DeviatorTrainingResult>> {
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(threads)
        .build()
        .map_err(|error| anyhow!("building deviator training thread pool: {error}"))?;
    pool.install(|| {
        (0..num_players)
            .into_par_iter()
            .map(|seat| solver.train_deviator_with_report(seat, traversals, seed, variant))
            .collect::<std::result::Result<Vec<_>, _>>()
    })
    .map_err(|error| anyhow!("training reference deviator: {error}"))
}

/// Result of one [`run_stop_rule_check`] call: the evaluation plus what
/// happened, so callers only do IO (printing/event-sending) and decide
/// whether to break their drive loop.
pub struct StopRuleCheck {
    pub evaluation: ProfileEvaluation,
    /// Maximum per-seat `deviation_gain_lower_bound` CI upper bound this
    /// check measured.
    pub max_upper: f64,
    /// Maximum per-seat `deviation_gain_lower_bound` CI width this check
    /// measured.
    pub max_width: f64,
    /// `Some(new_sample_count)` when this check's CI was too wide to ever
    /// settle below the threshold and the adaptive sample count was
    /// doubled (capped at [`MAX_STOP_RULE_SAMPLES`]); `None` otherwise.
    pub samples_doubled_to: Option<u64>,
    /// Whether `state.confirmations_met` (after this check) has reached
    /// `stop_rule.confirmations`.
    pub converged: bool,
}

/// Independent, reproducible streams for a scheduled stop check. Replaying
/// one fixed evaluation batch at every boundary would let a lucky batch
/// count repeatedly toward `confirmations`, even for an unchanged profile.
fn stop_check_seeds(seed: u64, sequence: u64) -> (u64, u64) {
    let derive = |domain: &[u8]| {
        let mut hasher = blake3::Hasher::new();
        hasher.update(domain);
        hasher.update(&seed.to_le_bytes());
        hasher.update(&sequence.to_le_bytes());
        u64::from_le_bytes(hasher.finalize().as_bytes()[..8].try_into().unwrap())
    };
    (
        derive(b"solvers.multiway.stop-training.v1"),
        derive(b"solvers.multiway.stop-held-out.v1"),
    )
}

/// One stop-rule check: an optional best-response burst, the held-out
/// evaluation, threshold/width bookkeeping, adaptive sample doubling, and
/// the confirmations update. Callers are expected to have already checked
/// their own wall-clock trigger (`state.last_eval.elapsed() >=
/// stop_rule.eval_period_secs`) before calling this; it unconditionally
/// performs one check and resets `state.last_eval`.
pub fn run_stop_rule_check(
    solver: &MultiwaySolver<HoldemGame<MultiwayAbstractionBackend>>,
    stop_rule: &StopRule,
    state: &mut StopRuleState,
    num_players: usize,
    threads: usize,
    evaluation_seed: u64,
) -> Result<StopRuleCheck> {
    state.last_eval = Instant::now();
    // One observation has no estimable sample variance. The diagnostic API
    // permits it, but its zero standard error must not certify a stop.
    // Persist and report the actual effective sample count.
    state.samples = state.samples.max(2);
    // Best-response burst: stop-rule evaluations measure a per-seat deviator
    // TRAINED against the frozen current average profile rather than the
    // plain regret-greedy heuristic the ordinary evaluation-cadence rows
    // use, so the deviation-gain numbers reported here are systematically
    // tighter (higher) than a cadence row taken at the same sweep count.
    // That is intentional: the stop decision should use the strongest
    // available deviator, not the cheap heuristic every metrics row gets.
    let (training_seed, held_out_seed) = stop_check_seeds(evaluation_seed, state.eval_index);
    state.eval_index = state
        .eval_index
        .checked_add(1)
        .context("stop-rule evaluation sequence overflow")?;
    let deviators = if stop_rule.br_traversals > 0 {
        Some(
            train_deviators_parallel(
                solver,
                num_players,
                threads,
                stop_rule.br_traversals,
                training_seed,
                multiway::ProfileVariant::default(),
            )
            .context("training best-response deviators for the convergence stop rule")?,
        )
    } else {
        None
    };
    let evaluation = solver
        .evaluate_profile(
            state.samples,
            held_out_seed,
            deviators.as_deref(),
            multiway::ProfileVariant::default(),
        )
        .context("evaluating multiway profile for the convergence stop rule")?;

    let bounds = evaluation
        .deviation_gain_lower_bound
        .as_ref()
        .expect("evaluate_profile always returns deviation_gain_lower_bound");
    let max_upper = bounds
        .iter()
        .map(|estimate| estimate.ci95[1])
        .fold(f64::NEG_INFINITY, f64::max);
    let max_width = bounds
        .iter()
        .map(|estimate| estimate.ci95[1] - estimate.ci95[0])
        .fold(0.0, f64::max);

    state.confirmations_met = if max_upper <= stop_rule.dev_gain_threshold {
        state.confirmations_met + 1
    } else {
        0
    };

    // The CI is wide enough that the check could never pass even if the
    // true value already converged: double the sample count for subsequent
    // stop-rule checks (capped), so noise shrinks over time instead of
    // blocking convergence forever.
    let samples_doubled_to =
        if max_width > stop_rule.dev_gain_threshold && state.samples < MAX_STOP_RULE_SAMPLES {
            let doubled = state.samples.saturating_mul(2).min(MAX_STOP_RULE_SAMPLES);
            let changed = doubled != state.samples;
            state.samples = doubled;
            changed.then_some(doubled)
        } else {
            None
        };

    Ok(StopRuleCheck {
        evaluation,
        max_upper,
        max_width,
        samples_doubled_to,
        converged: state.confirmations_met >= stop_rule.confirmations,
    })
}

/// The `[game]`/`[rake]`/`[utility]`-only core of `build_multiway_session`:
/// builds (or loads/retrains) the configured card abstraction and returns a
/// ready-to-use game plus its deal sampler, without touching
/// `[algorithm]`/`[run]` or constructing a solver.
fn build_multiway_game_from_config(
    game_config: &multiway::MultiwayConfig,
    utility: &MultiwayUtility,
    rake: &MultiwayRake,
    abstraction_policy: AbstractionPolicy,
) -> Result<(
    HoldemGame<MultiwayAbstractionBackend>,
    DealSampler,
    Option<AbstractionReady>,
)> {
    game_config
        .validate_economics(utility, rake)
        .context("validating multiway game and utility")?;
    // Only the EHS² backend has a table worth reporting; the test baseline
    // is built in microseconds.
    #[allow(unused_assignments)]
    let mut ready = None;
    let abstraction = match abstraction_policy {
        #[cfg(test)]
        AbstractionPolicy::CheapBaseline => MultiwayAbstractionBackend::FeatureHash(
            FeatureHashAbstraction::new(FeatureHashParams {
                flop_buckets: u32::from(game_config.abstraction.flop_buckets),
                turn_buckets: u32::from(game_config.abstraction.turn_buckets),
                river_buckets: u32::from(game_config.abstraction.river_buckets),
            })
            .context("building the feature-hash baseline abstraction")?,
        ),
        AbstractionPolicy::Configured => match game_config.abstraction.kind {
            AbstractionKind::RolloutKmeans => {
                return Err(anyhow!(
                    "MWP001: rollout-kmeans was removed; use kind = \"ehs2-table\""
                ));
            }
            AbstractionKind::Ehs2Table => {
                let (table, report) = build_ehs2_table_abstraction(game_config)?;
                ready = Some(report);
                MultiwayAbstractionBackend::Ehs2Table(table)
            }
        },
    };
    let game = HoldemGame::new(game_config, utility, rake, abstraction)
        .context("building generative multiway game")?;
    let sampler = game.deal_sampler().context("compiling table ranges")?;
    Ok((game, sampler, ready))
}

/// Builds (or loads, or rebuilds-and-overwrites -- see
/// `Ehs2Abstraction::load_or_build`) the precomputed EHS² percentile-table
/// abstraction for `AbstractionKind::Ehs2Table`, reusing the same
/// `artifact_cache` config key the rollout backend uses for its own
/// (differently-shaped) artifact. Unlike the rollout backend, there is no
/// separate assignment cache to persist after a solve: the table is fully
/// determined by `params` at build time.
fn build_ehs2_table_abstraction(
    game_config: &multiway::MultiwayConfig,
) -> Result<(TableAbstractionAdapter<Ehs2Abstraction>, AbstractionReady)> {
    let params = Ehs2Params {
        flop_buckets: u32::from(game_config.abstraction.flop_buckets),
        turn_buckets: u32::from(game_config.abstraction.turn_buckets),
        river_buckets: u32::from(game_config.abstraction.river_buckets),
    };
    // A config may still name its own cache file; otherwise the table comes
    // from the machine-scoped cache, which is where a 543 MB artifact that
    // depends only on the bucket counts belongs.
    let machine_cache = match game_config.abstraction.artifact_cache {
        Some(_) => None,
        None => crate::cache::ehs2_table(params)?,
    };
    let cache = game_config
        .abstraction
        .artifact_cache
        .as_deref()
        .or(machine_cache.as_deref());
    if let Some(parent) = cache
        .and_then(Path::parent)
        .filter(|parent| !parent.as_os_str().is_empty())
    {
        std::fs::create_dir_all(parent)
            .with_context(|| format!("creating ehs2 table cache directory {}", parent.display()))?;
    }
    let cached = cache.is_some_and(Path::is_file);
    let start = Instant::now();
    let streets = [
        cards::Street::Flop,
        cards::Street::Turn,
        cards::Street::River,
    ];
    let table = Ehs2Abstraction::load_or_build(params, &streets, cache);
    eprintln!(
        "ehs2 tables: {} in {:.2}s",
        if cached { "loaded" } else { "built" },
        start.elapsed().as_secs_f64()
    );
    Ok((
        TableAbstractionAdapter::new(table, ehs2_table_fingerprint(params)),
        AbstractionReady {
            cached,
            secs: start.elapsed().as_secs_f64(),
        },
    ))
}

/// Converts the config-schema `[utility]` section into the solver's
/// `MultiwayUtility`, running cheap `validate_economics` checks without
/// paying for a full `build_multiway_session` (which also trains the card
/// abstraction and builds the game).
pub(crate) fn convert_utility(utility: UtilitySection) -> Result<MultiwayUtility> {
    Ok(match utility {
        UtilitySection::ChipEv => MultiwayUtility::ChipEv,
        UtilitySection::TournamentIcm {
            outside_field,
            payouts,
            samples,
            seed,
        } => MultiwayUtility::TournamentIcm {
            outside_field: outside_field
                .into_iter()
                .map(|player| FieldPlayerConfig {
                    name: player.name,
                    stack_bb: player.stack_bb,
                })
                .collect(),
            payouts,
            samples,
            seed,
        },
        UtilitySection::Icm { .. } => {
            return Err(anyhow!(
                "legacy HU utility kind = \"icm\" is not valid for preflop-multiway; use kind = \"tournament-icm\""
            ));
        }
    })
}

/// Converts the config-schema `[rake]` section into the solver's
/// `MultiwayRake`.
pub(crate) fn convert_rake(rake: RakeSection) -> MultiwayRake {
    match rake {
        RakeSection::None => MultiwayRake::None,
        RakeSection::PercentCap {
            rate,
            cap,
            no_flop_no_drop,
        } => MultiwayRake::PercentCap {
            rate,
            cap_bb: cap / multiway::types::CHIPS_PER_BB as f64,
            no_flop_no_drop,
        },
        RakeSection::Generic {
            rate,
            cap,
            when,
            allocation,
            rounding,
            // Multiway's own rake grammar fixes the rounding unit at
            // `.001 BB`; only the heads-up families make it configurable.
            rounding_unit: _,
        } => MultiwayRake::Generic {
            rate,
            cap_bb: cap,
            when,
            allocation,
            rounding,
        },
        RakeSection::GgPreflop {
            rate,
            cap,
            exempt_pot,
        } => MultiwayRake::GgPreflop {
            rate,
            cap_bb: cap / multiway::types::CHIPS_PER_BB as f64,
            exempt_pot_bb: exempt_pot as f64 / 1_000.0,
        },
    }
}

/// Sweeps until the next `cadence` boundary (a full `cadence` when already
/// on one). Both the CLI and GUI drive loops size their chunks with this so
/// evaluation/checkpoint cadences fire exactly on their configured multiples.
pub fn distance_to_boundary(current: u64, cadence: u64) -> u64 {
    cadence - current % cadence
}

/// Assembles one `MultiwayMetricsRow` from solver metrics, drift, elapsed
/// time, and an optional held-out profile evaluation.
pub fn metrics_row(
    metrics: &multiway::SolverMetrics,
    drift: Vec<f64>,
    elapsed_secs: f64,
    evaluation: Option<&ProfileEvaluation>,
) -> MultiwayMetricsRow {
    MultiwayMetricsRow {
        schema_version: MULTIWAY_SCHEMA_VERSION,
        phase: "sampling".to_string(),
        sweeps: metrics.sweeps,
        traversals: metrics.traversals,
        elapsed_secs,
        infosets: metrics.infosets,
        memory_bytes: metrics.memory_bytes,
        traversals_per_second: if elapsed_secs > 0.0 {
            metrics.traversals as f64 / elapsed_secs
        } else {
            0.0
        },
        hand_updates: metrics.hand_updates,
        hand_updates_per_second: if elapsed_secs > 0.0 {
            metrics.hand_updates as f64 / elapsed_secs
        } else {
            0.0
        },
        seats: metrics
            .average_positive_regret
            .iter()
            .enumerate()
            .map(|(seat, &regret)| MultiwaySeatMetrics {
                seat: seat as u8,
                profile_ev: evaluation
                    .and_then(|value| value.seats.get(seat))
                    .map(profile_estimate),
                average_positive_regret: regret,
                strategy_drift_l1: drift[seat],
                deviation_gain_lower_bound: evaluation
                    .and_then(|value| value.deviation_gain_lower_bound.as_ref())
                    .and_then(|values| values.get(seat))
                    .map(profile_estimate),
                candidate_policy_coverage: evaluation
                    .and_then(|value| value.candidate_policy_coverage.get(seat))
                    .map(policy_coverage),
            })
            .collect(),
    }
}

fn profile_estimate(value: &multiway::solver::ProfileEstimate) -> Estimate {
    Estimate {
        mean: value.mean,
        stderr: value.stderr,
        ci95: value.ci95,
    }
}

fn policy_coverage(value: &multiway::CandidatePolicyCoverage) -> formats::MultiwayPolicyCoverage {
    let by_street = |counts: multiway::StreetVisitCounts| formats::MultiwayStreetVisitCounts {
        preflop: counts.preflop,
        flop: counts.flop,
        turn: counts.turn,
        river: counts.river,
    };
    formats::MultiwayPolicyCoverage {
        decision_visits: value.decision_visits,
        stored_strategy_visits: value.stored_strategy_visits,
        uniform_fallback_visits: value.uniform_fallback_visits,
        average_strategy_visits: value.average_strategy_visits,
        current_strategy_visits: value.current_strategy_visits,
        regret_fallback_visits: value.regret_fallback_visits,
        decision_visits_by_street: by_street(value.decision_visits_by_street),
        stored_strategy_visits_by_street: by_street(value.stored_strategy_visits_by_street),
        uniform_fallback_visits_by_street: by_street(value.uniform_fallback_visits_by_street),
        average_strategy_visits_by_street: by_street(value.average_strategy_visits_by_street),
        current_strategy_visits_by_street: by_street(value.current_strategy_visits_by_street),
        regret_fallback_visits_by_street: by_street(value.regret_fallback_visits_by_street),
    }
}

fn public_action(action: &multiway::Action) -> MultiwayPublicAction {
    match action {
        multiway::Action::Fold => MultiwayPublicAction::Fold,
        multiway::Action::Check => MultiwayPublicAction::Check,
        multiway::Action::Call { amount, all_in } => MultiwayPublicAction::Call {
            amount_millibb: amount.raw(),
            all_in: *all_in,
        },
        multiway::Action::BetTo {
            to,
            all_in,
            full_raise,
        } => MultiwayPublicAction::BetTo {
            amount_millibb: to.raw(),
            all_in: *all_in,
            full_raise: *full_raise,
        },
        multiway::Action::RaiseTo {
            to,
            all_in,
            full_raise,
        } => MultiwayPublicAction::RaiseTo {
            amount_millibb: to.raw(),
            all_in: *all_in,
            full_raise: *full_raise,
        },
    }
}

fn make_public_tree(
    game: &HoldemGame<MultiwayAbstractionBackend>,
) -> (Vec<MultiwayHistoryNode>, Vec<MultiwayPublicState>) {
    let root = multiway::solver::ExternalSamplingGame::root_state(game);
    let mut pending = vec![(multiway::solver::HistoryKey::ROOT, root)];
    let mut histories = Vec::new();
    let mut public_states = Vec::new();

    while let Some((history, state)) = pending.pop() {
        let actor = state.to_act.map(|seat| seat.0);
        let actions = game.legal_actions(&state);
        public_states.push(MultiwayPublicState {
            history: history.0,
            street: state.street.index() as u8,
            actor,
            pot_millibb: state.pot_size().raw(),
            remaining_stacks_millibb: state
                .seats
                .iter()
                .map(|seat| seat.remaining.raw())
                .collect(),
            legal_actions: actions.iter().map(public_action).collect(),
        });
        let Some(actor) = actor else {
            continue;
        };
        for (action_index, action) in actions.iter().enumerate().rev() {
            let child = history.child(actor as usize, action_index);
            histories.push(MultiwayHistoryNode {
                key: child.0,
                parent: history.0,
                actor,
                action_index: action_index as u32,
                action: public_action(action).label(),
            });
            let next = multiway::solver::ExternalSamplingGame::next_state_with(
                game,
                &state,
                &actions,
                action_index,
            );
            pending.push((child, next));
        }
    }

    histories.sort_by_key(|entry| entry.key);
    public_states.sort_by_key(|state| state.history);
    (histories, public_states)
}

/// Identifies both configured algorithm settings and the numerical update
/// semantics. Shared by the run summary and `.mwsol` writers so artifacts
/// from before a solver-state correction remain distinguishable.
pub(crate) fn multiway_algorithm_fingerprint(
    algorithm: &crate::config::AlgorithmSection,
) -> Result<[u8; 32]> {
    let material = serde_json::to_vec(algorithm)?;
    let mut hasher = blake3::Hasher::new();
    hasher.update(b"solvers.multiway.algorithm.v1");
    hasher.update(&multiway::solver::SOLVER_STATE_VERSION.to_le_bytes());
    hasher.update(&material);
    Ok(*hasher.finalize().as_bytes())
}

/// Builds the exportable `.mwsol` artifact from a solver state snapshot and
/// its final metrics row. Only visited infosets are formal solution entries;
/// absent keys remain explicitly unvisited rather than becoming uniform.
/// Shared by every caller that persists a multiway solve's average strategy.
pub fn make_solution(
    config_toml: &str,
    abstraction_fingerprint: [u8; 32],
    configuration_fingerprint: [u8; 32],
    game: &HoldemGame<MultiwayAbstractionBackend>,
    state: &multiway::solver::SolverState,
    row: &MultiwayMetricsRow,
) -> MultiwaySolution {
    let effective = crate::config::parse_internal_config(config_toml)
        .expect("solution config was validated before solving");
    let algorithm_fingerprint = multiway_algorithm_fingerprint(&effective.algorithm)
        .expect("effective algorithm is serializable");
    let (histories, public_states) = make_public_tree(game);
    let strategy_weights = state
        .policies
        .iter()
        .filter(|entry| entry.column.strategy_sum.iter().any(|value| *value > 0.0))
        .map(|entry| MultiwayStrategyWeight {
            key: MultiwayStrategyKey {
                history: entry.key.history.0,
                actor: entry.key.player,
                street: entry.key.street,
                active_opponents: entry.key.active_opponents,
                bucket_path: entry.key.bucket_path,
            },
            weight: entry
                .column
                .strategy_sum
                .iter()
                .map(|value| f64::from(*value))
                .sum(),
        })
        .collect();
    let strategies = state
        .policies
        .iter()
        .filter(|entry| entry.column.strategy_sum.iter().any(|value| *value > 0.0))
        .map(|entry| MultiwayStrategyBlock {
            key: MultiwayStrategyKey {
                history: entry.key.history.0,
                actor: entry.key.player,
                street: entry.key.street,
                active_opponents: entry.key.active_opponents,
                bucket_path: entry.key.bucket_path,
            },
            actions: entry.column.action_labels.clone(),
            probabilities: entry.column.average_strategy(),
        })
        .collect();
    MultiwaySolution {
        schema_version: MULTIWAY_SCHEMA_VERSION,
        config_toml: config_toml.to_string(),
        config_fingerprint: formats::config_hash(config_toml.as_bytes()),
        game_fingerprint: game.game_fingerprint(),
        algorithm_fingerprint,
        abstraction_fingerprint,
        configuration_fingerprint,
        stop_status: row.phase.clone(),
        chip_unit_bb: 0.001,
        sweeps: row.sweeps,
        approximate_profile: true,
        histories,
        seats: row
            .seats
            .iter()
            .map(|seat| MultiwaySeatResult {
                seat: seat.seat,
                profile_ev: seat.profile_ev.clone(),
                average_positive_regret: seat.average_positive_regret,
                strategy_drift_l1: seat.strategy_drift_l1,
                deviation_gain_lower_bound: seat.deviation_gain_lower_bound.clone(),
            })
            .collect(),
        strategies,
        public_states,
        strategy_weights,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::RakeSection;
    use multiway::solver::DEFAULT_PRUNE_SKIP_PROBABILITY;

    #[test]
    fn algorithm_identity_distinguishes_corrected_updates_from_legacy_artifacts() {
        let config =
            crate::config::parse_internal_config(crate::test_fixtures::LOWERED_3MAX).unwrap();
        let old_identity = formats::config_hash(&serde_json::to_vec(&config.algorithm).unwrap());
        let corrected = multiway_algorithm_fingerprint(&config.algorithm).unwrap();
        assert_ne!(old_identity, corrected);
        let restored: crate::config::AlgorithmSection =
            serde_json::from_slice(&serde_json::to_vec(&config.algorithm).unwrap()).unwrap();
        assert_eq!(
            corrected,
            multiway_algorithm_fingerprint(&restored).unwrap()
        );
    }

    #[test]
    fn progress_policy_coverage_reports_only_the_held_out_baseline() {
        let session = build_multiway_session(crate::test_fixtures::LOWERED_3MAX, None).unwrap();
        let evaluation = session.solver.evaluate_average_profile(16, 5041).unwrap();
        let metrics = session.solver.metrics();
        let row = metrics_row(&metrics, vec![0.0; 3], 1.0, Some(&evaluation));
        let json = serde_json::to_value(&row).unwrap();
        let mut total_visits = 0;
        for (seat, expected) in evaluation.candidate_policy_coverage.iter().enumerate() {
            let observed = row.seats[seat].candidate_policy_coverage.as_ref().unwrap();
            total_visits += observed.decision_visits;
            assert_eq!(observed.decision_visits, expected.decision_visits);
            assert_eq!(observed.uniform_fallback_visits, observed.decision_visits);
            assert_eq!(observed.stored_strategy_visits, 0);
            assert_eq!(observed.average_strategy_visits, 0);
            assert_eq!(observed.current_strategy_visits, 0);
            assert_eq!(observed.regret_fallback_visits, 0);
            assert_eq!(
                observed.uniform_fallback_visits_by_street,
                observed.decision_visits_by_street
            );
            assert_eq!(
                json["seats"][seat]["candidatePolicyCoverage"]["uniformFallbackVisitsByStreet"]["flop"],
                expected.uniform_fallback_visits_by_street.flop
            );
        }
        assert!(total_visits > 0);
        let without_evaluation = metrics_row(&metrics, vec![0.0; 3], 1.0, None);
        assert!(
            without_evaluation
                .seats
                .iter()
                .all(|seat| seat.candidate_policy_coverage.is_none())
        );
    }

    #[test]
    fn stop_checks_use_fresh_held_out_batches_and_resume_the_sequence() {
        let session = build_multiway_session(crate::test_fixtures::LOWERED_3MAX, None)
            .expect("build cheap frozen-profile fixture");
        let rule = StopRule {
            dev_gain_threshold: 1.0e6,
            confirmations: 3,
            eval_period_secs: 1.0,
            br_traversals: 0,
        };
        let mut state = StopRuleState::new(32);
        let seed = 29;
        let first = run_stop_rule_check(&session.solver, &rule, &mut state, 3, 1, seed).unwrap();
        let expected = session
            .solver
            .evaluate_average_profile(32, stop_check_seeds(seed, 0).1)
            .unwrap();
        assert_eq!(first.evaluation, expected);
        assert!(!first.converged);

        // This is exactly the persisted stop-state subset restored by the
        // drive loop, without involving wall-clock time in reproducibility.
        let mut resumed = StopRuleState::new(state.samples);
        resumed.eval_index = state.eval_index;
        resumed.confirmations_met = state.confirmations_met;
        let second = run_stop_rule_check(&session.solver, &rule, &mut state, 3, 1, seed).unwrap();
        let replay = run_stop_rule_check(&session.solver, &rule, &mut resumed, 3, 1, seed).unwrap();
        assert_eq!(second.evaluation, replay.evaluation);
        assert_eq!(
            second.evaluation,
            session
                .solver
                .evaluate_average_profile(32, stop_check_seeds(seed, 1).1)
                .unwrap()
        );
        assert_eq!(state.eval_index, resumed.eval_index);
        assert_ne!(first.evaluation, second.evaluation);
        assert_eq!(state.confirmations_met, 2);

        let mut streams = std::collections::HashSet::new();
        for sequence in 0..64 {
            let (training, held_out) = stop_check_seeds(seed, sequence);
            assert!(streams.insert(training));
            assert!(streams.insert(held_out));
        }
    }

    #[test]
    fn stop_target_includes_equality_at_the_upper_bound() {
        let session = build_multiway_session(crate::test_fixtures::LOWERED_3MAX, None).unwrap();
        let mut state = StopRuleState::new(32);
        let seed = 31;
        let expected = session
            .solver
            .evaluate_average_profile(32, stop_check_seeds(seed, 0).1)
            .unwrap();
        let target = expected
            .deviation_gain_lower_bound
            .unwrap()
            .iter()
            .map(|estimate| estimate.ci95[1])
            .fold(0.0, f64::max);
        let rule = StopRule {
            dev_gain_threshold: target,
            confirmations: 1,
            eval_period_secs: 1.0,
            br_traversals: 0,
        };
        let check = run_stop_rule_check(&session.solver, &rule, &mut state, 3, 1, seed).unwrap();
        assert_eq!(check.max_upper, target);
        assert!(check.converged);
    }

    #[test]
    fn stop_check_requires_variance_samples_and_rejects_sequence_overflow() {
        let session = build_multiway_session(crate::test_fixtures::LOWERED_3MAX, None).unwrap();
        let rule = StopRule {
            dev_gain_threshold: 1.0e6,
            confirmations: 1,
            eval_period_secs: 1.0,
            br_traversals: 0,
        };
        let mut state = StopRuleState::new(1);
        let check = run_stop_rule_check(&session.solver, &rule, &mut state, 3, 1, 17).unwrap();
        assert_eq!(check.evaluation.samples, 2);
        assert_eq!(state.samples, 2);
        state.eval_index = u64::MAX;
        let error = run_stop_rule_check(&session.solver, &rule, &mut state, 3, 1, 17)
            .err()
            .expect("sequence exhaustion must fail rather than reuse a batch");
        assert!(error.to_string().contains("sequence overflow"));
    }

    #[test]
    fn boundaries_are_positive_and_repeat() {
        assert_eq!(distance_to_boundary(0, 100), 100);
        assert_eq!(distance_to_boundary(99, 100), 1);
        assert_eq!(distance_to_boundary(100, 100), 100);
    }

    #[test]
    fn production_policy_memory_auto_is_six_gib_and_explicit_values_pass_through() {
        let limit = crate::multiway_v1::PRODUCTION_POLICY_ARENA_AUTO_BYTES;
        assert_eq!(
            resolve_policy_memory_limit(SessionStoragePolicy::PreallocatedProduction, None)
                .unwrap(),
            limit
        );
        assert_eq!(
            resolve_policy_memory_limit(
                SessionStoragePolicy::PreallocatedProduction,
                Some(u64::MAX),
            )
            .unwrap(),
            limit
        );
        assert_eq!(
            resolve_policy_memory_limit(SessionStoragePolicy::PreallocatedProduction, Some(limit),)
                .unwrap(),
            limit
        );
        assert_eq!(
            resolve_policy_memory_limit(
                SessionStoragePolicy::PreallocatedProduction,
                Some(limit + 1),
            )
            .unwrap(),
            limit + 1
        );
        assert_eq!(
            resolve_policy_memory_limit(SessionStoragePolicy::Compatibility, Some(u64::MAX))
                .unwrap(),
            u64::MAX
        );
    }

    #[test]
    fn shared_rake_chip_units_convert_to_multiway_bb() {
        let rake = convert_rake(RakeSection::PercentCap {
            rate: 0.05,
            cap: 3_500.0,
            no_flop_no_drop: true,
        });
        assert!(matches!(
            rake,
            MultiwayRake::PercentCap {
                cap_bb: 3.5,
                no_flop_no_drop: true,
                ..
            }
        ));
    }

    #[test]
    fn legacy_hu_icm_is_rejected_on_multiway_path() {
        let error = convert_utility(UtilitySection::Icm {
            payouts: [1.0, 0.0],
        })
        .unwrap_err();
        assert!(error.to_string().contains("tournament-icm"));
    }

    #[test]
    fn production_session_initialization_and_resume_preserve_thread_independent_state() {
        let base = crate::test_fixtures::LOWERED_3MAX.replace("sweeps = 2\n", "sweeps = 8\n");
        let serial_raw = base.replace("[run]\n", "[run]\nthreads = 1\n");
        let parallel_raw = base.replace("[run]\n", "[run]\nthreads = 8\n");
        assert_ne!(serial_raw, base);
        let build = |raw: &str, checkpoint: Option<&std::path::Path>| {
            build_multiway_session_internal(
                raw,
                None,
                checkpoint,
                SessionStoragePolicy::PreallocatedProduction,
                AbstractionPolicy::CheapBaseline,
            )
            .unwrap()
        };
        let mut serial = build(&serial_raw, None);
        let mut parallel = build(&parallel_raw, None);
        assert_eq!(serial.threads, 1);
        assert_eq!(parallel.threads, 8);
        assert_eq!(
            serial.solver.policy_arena_allocation(),
            parallel.solver.policy_arena_allocation()
        );
        assert!(
            parallel
                .solver
                .policy_arena_allocation()
                .unwrap()
                .pages_committed
        );
        serial
            .solver
            .run_sweeps_with_threads(4, serial.threads)
            .unwrap();
        parallel
            .solver
            .run_sweeps_with_threads(4, parallel.threads)
            .unwrap();
        let checkpoint = MultiwayCheckpoint::capture(&serial.solver);
        assert_eq!(checkpoint, MultiwayCheckpoint::capture(&parallel.solver));
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("parallel-construction.mwckpt");
        checkpoint.write_atomic(&path).unwrap();
        let mut resumed = build(&parallel_raw, Some(&path));
        assert_eq!(resumed.threads, 8);
        assert_eq!(checkpoint, MultiwayCheckpoint::capture(&resumed.solver));
        serial
            .solver
            .run_sweeps_with_threads(2, serial.threads)
            .unwrap();
        resumed
            .solver
            .run_sweeps_with_threads(2, resumed.threads)
            .unwrap();
        assert_eq!(
            MultiwayCheckpoint::capture(&serial.solver),
            MultiwayCheckpoint::capture(&resumed.solver)
        );
    }

    #[test]
    fn multiway_example_builds_a_session() {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let session = build_multiway_session(raw, None).expect("build multiway session");
        assert_eq!(session.sweeps_target, 2);
        assert_eq!(session.config_toml, raw);
        assert_eq!(session.stop_rule, None);
        assert_eq!(session.deviation_reference, None);
        assert!(session.solver.game().deviation_abstraction().is_none());
    }

    #[cfg(feature = "research-draw-abstraction")]
    fn research_test_abstraction(buckets: u32) -> FeatureHashAbstraction {
        FeatureHashAbstraction::new(FeatureHashParams {
            flop_buckets: buckets,
            turn_buckets: buckets,
            river_buckets: buckets,
        })
        .unwrap()
    }

    #[cfg(feature = "research-draw-abstraction")]
    #[test]
    fn research_supplied_abstraction_preserves_dense_session_and_updates() {
        let raw = crate::test_fixtures::LOWERED_3MAX
            .replace("checkpoint_every = 1\n", "")
            .replace("[algorithm]\n", "[algorithm]\ntraverser_vector = true\n")
            .replace("[run]\n", "[run]\nsweep_batch = 2\nthreads = 2\n");
        let mut expected = build_multiway_session_internal(
            &raw,
            None,
            None,
            SessionStoragePolicy::PreallocatedProduction,
            AbstractionPolicy::CheapBaseline,
        )
        .unwrap();
        let mut research =
            build_research_multiway_session(&raw, research_test_abstraction(8)).unwrap();
        assert_eq!(research.config_hash, expected.config_hash);
        assert_eq!(research.sweeps_target, expected.sweeps_target);
        assert_eq!(research.threads, expected.threads);
        assert_eq!(research.evaluation_cadence, expected.evaluation_cadence);
        assert_eq!(research.evaluation_samples, expected.evaluation_samples);
        assert_eq!(research.evaluation_seed, expected.evaluation_seed);
        assert_eq!(research.stop_rule, expected.stop_rule);
        assert!(
            research
                .solver
                .policy_arena_allocation()
                .unwrap()
                .pages_committed
        );
        assert_eq!(
            MultiwayCheckpoint::capture(&research.solver),
            MultiwayCheckpoint::capture(&expected.solver)
        );
        expected.solver.run_sweeps_with_threads(4, 2).unwrap();
        research.solver.run_sweeps_with_threads(4, 2).unwrap();
        assert_eq!(
            MultiwayCheckpoint::capture(&research.solver),
            MultiwayCheckpoint::capture(&expected.solver),
            "supplied backend must preserve full regret/average state and sample sequence"
        );
    }

    #[cfg(feature = "research-draw-abstraction")]
    #[test]
    fn research_session_rejects_wrong_budgets_and_unsupported_contracts() {
        let raw = crate::test_fixtures::LOWERED_3MAX.replace("checkpoint_every = 1\n", "");
        let error = build_research_multiway_session(&raw, research_test_abstraction(4))
            .err()
            .expect("mismatched effective budget must fail");
        assert!(error.to_string().contains("bucket mismatch"));
        let full = raw.replace("recall = \"street\"", "recall = \"full\"");
        let error = build_research_multiway_session(&full, research_test_abstraction(8))
            .err()
            .expect("research must not enable removed recall mode");
        assert!(error.to_string().contains("MWP002"));
        let error = build_research_multiway_session(
            crate::test_fixtures::LOWERED_3MAX,
            research_test_abstraction(8),
        )
        .err()
        .expect("one-shot helper must reject checkpoint scheduling");
        assert!(error.to_string().contains("checkpoint_every"));
    }

    #[cfg(feature = "research-draw-abstraction")]
    #[test]
    fn research_session_checks_preflop_and_every_opponent_count() {
        struct BadCounts {
            street: Street,
            opponents: u8,
        }
        impl MultiwayAbstraction for BadCounts {
            fn num_buckets(&self, street: Street, opponents: u8) -> u32 {
                if street == self.street && opponents == self.opponents {
                    1
                } else if street == Street::Preflop {
                    169
                } else {
                    8
                }
            }
            fn bucket(&self, _: BucketContext<'_>) -> BucketId {
                panic!("invalid backend must fail before traversal")
            }
            fn fingerprint(&self) -> [u8; 32] {
                [1; 32]
            }
        }
        let raw = crate::test_fixtures::LOWERED_3MAX.replace("checkpoint_every = 1\n", "");
        for (street, opponents) in [(Street::Preflop, 0), (Street::River, 8)] {
            let error = build_research_multiway_session(&raw, BadCounts { street, opponents })
                .err()
                .expect("all declared contexts must be checked before allocation");
            let message = error.to_string();
            assert!(message.contains("bucket mismatch"), "{message}");
            assert!(message.contains(&format!("active_opponents={opponents}")));
        }
    }

    #[test]
    fn common_deviation_reference_attaches_before_checkpoint_restore() {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let reference_raw = raw
            .replace("flop_buckets = 8", "flop_buckets = 4")
            .replace("turn_buckets = 8", "turn_buckets = 4")
            .replace("river_buckets = 8", "river_buckets = 4")
            .replace("seed = 17", "seed = 23");
        let directory = tempfile::tempdir().unwrap();
        let checkpoint_path = directory.path().join("candidate.mwckpt");

        let mut original = build_multiway_session(raw, None).unwrap();
        original.solver.run_sweeps(1).unwrap();
        let candidate_configuration = original.solver.configuration_fingerprint();
        let candidate_abstraction = original.solver.abstraction_fingerprint();
        MultiwayCheckpoint::capture(&original.solver)
            .write_atomic(&checkpoint_path)
            .unwrap();

        let restored =
            build_multiway_session_with_deviation(raw, &reference_raw, Some(&checkpoint_path))
                .unwrap();
        assert_eq!(restored.solver.metrics().sweeps, 1);
        assert_eq!(
            restored.solver.configuration_fingerprint(),
            candidate_configuration
        );
        assert_eq!(
            restored.solver.abstraction_fingerprint(),
            candidate_abstraction
        );
        let reference = restored
            .deviation_reference
            .as_ref()
            .expect("reference metadata");
        assert_ne!(reference.abstraction_fingerprint, candidate_abstraction);
        assert_eq!(reference.recall, RecallMode::Street);
        assert!(restored.solver.game().deviation_abstraction().is_some());
    }

    #[test]
    fn common_deviation_reference_rejects_a_different_game() {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let different_game = raw.replacen("stack_bb = 2.0", "stack_bb = 3.0", 1);
        let error = build_multiway_session_with_deviation(raw, &different_game, None)
            .err()
            .expect("different game must fail");
        let error = format!("{error:#}");
        assert!(
            error.contains("candidate/reference game fingerprint mismatch"),
            "unexpected error: {error}"
        );
    }

    fn with_stop_dev_gain(dev_gain: &str, extra: &str) -> String {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let anchor = "evaluation_cadence = 1\n";
        let spliced = raw.replacen(
            anchor,
            &format!("{anchor}stop_dev_gain = {dev_gain}\n{extra}"),
            1,
        );
        assert_ne!(spliced, raw, "the splice anchor must have matched");
        spliced
    }

    #[test]
    fn stop_dev_gain_defaults_confirmations_and_period_when_omitted() {
        let raw = with_stop_dev_gain("0.5", "");
        let session = build_multiway_session(&raw, None).expect("build multiway session");
        assert_eq!(
            session.stop_rule,
            Some(StopRule {
                dev_gain_threshold: 0.5,
                confirmations: DEFAULT_STOP_CONFIRMATIONS,
                eval_period_secs: DEFAULT_STOP_EVAL_PERIOD_SECS,
                br_traversals: DEFAULT_STOP_BR_TRAVERSALS,
            })
        );
    }

    #[test]
    fn stop_dev_gain_honors_explicit_confirmations_and_period() {
        let raw = with_stop_dev_gain(
            "0.5",
            "stop_confirmations = 5\nstop_eval_period_secs = 12.5\nstop_br_traversals = 123\n",
        );
        let session = build_multiway_session(&raw, None).expect("build multiway session");
        assert_eq!(
            session.stop_rule,
            Some(StopRule {
                dev_gain_threshold: 0.5,
                confirmations: 5,
                eval_period_secs: 12.5,
                br_traversals: 123,
            })
        );
    }

    /// `MultiwaySession` intentionally does not derive `Debug` (it embeds a
    /// live `MultiwaySolver`), so validation-error tests extract the error
    /// string by hand rather than via `Result::unwrap_err`.
    fn build_multiway_session_err(raw: &str) -> String {
        match build_multiway_session(raw, None) {
            Ok(_) => panic!("expected build_multiway_session to fail"),
            Err(error) => error.to_string(),
        }
    }

    #[test]
    fn stop_dev_gain_rejects_nonpositive_thresholds() {
        for bad in ["0.0", "-1.0"] {
            let raw = with_stop_dev_gain(bad, "");
            let error = build_multiway_session_err(&raw);
            assert!(error.contains("stop_dev_gain"), "{bad}: {error}");
        }
    }

    #[test]
    fn stop_confirmations_zero_is_rejected() {
        let raw = with_stop_dev_gain("0.5", "stop_confirmations = 0\n");
        let error = build_multiway_session_err(&raw);
        assert!(error.contains("stop_confirmations"));
    }

    #[test]
    fn stop_eval_period_secs_nonpositive_is_rejected() {
        let raw = with_stop_dev_gain("0.5", "stop_eval_period_secs = 0.0\n");
        let error = build_multiway_session_err(&raw);
        assert!(error.contains("stop_eval_period_secs"));
    }

    /// Splices `extra` right after `discount_until` in `[algorithm]`,
    /// mirroring `with_stop_dev_gain`'s splice-into-`[run]` helper.
    fn with_algorithm_extra(extra: &str) -> String {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let anchor = "discount_until = 10000000\n";
        let spliced = raw.replacen(anchor, &format!("{anchor}{extra}"), 1);
        assert_ne!(spliced, raw, "the splice anchor must have matched");
        spliced
    }

    #[test]
    fn prune_without_explicit_threshold_derives_from_chip_ev_stakes() {
        let raw = with_algorithm_extra("traverser_vector = true\nprune = true\n");
        let session = build_multiway_session(&raw, None).expect("build multiway session");
        let config = session.solver.config();
        assert!(config.prune);
        // The smoke config has 3 seats at 2.0 bb each: -10 * 6.0 = -60.0.
        assert_eq!(config.prune_threshold, -60.0);
        assert_eq!(
            config.prune_skip_probability,
            DEFAULT_PRUNE_SKIP_PROBABILITY
        );
    }

    #[test]
    fn prune_with_explicit_threshold_uses_it_verbatim() {
        let raw = with_algorithm_extra(
            "traverser_vector = true\nprune = true\nprune_threshold = -42.0\nprune_skip_probability = 0.5\n",
        );
        let session = build_multiway_session(&raw, None).expect("build multiway session");
        let config = session.solver.config();
        assert!(config.prune);
        assert_eq!(config.prune_threshold, -42.0);
        assert_eq!(config.prune_skip_probability, 0.5);
    }

    #[test]
    fn prune_disabled_by_default_and_ignores_the_derivation() {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let session = build_multiway_session(raw, None).expect("build multiway session");
        let config = session.solver.config();
        assert!(!config.prune);
        assert_eq!(config.prune_threshold, DEFAULT_PRUNE_THRESHOLD);
    }

    #[test]
    fn prune_without_traverser_vector_is_rejected() {
        let raw = with_algorithm_extra("prune = true\n");
        let error = build_multiway_session_err(&raw);
        assert!(error.contains("traverser_vector"), "{error}");
    }

    #[test]
    fn prune_threshold_nonnegative_is_rejected() {
        let raw =
            with_algorithm_extra("traverser_vector = true\nprune = true\nprune_threshold = 0.0\n");
        let error = build_multiway_session_err(&raw);
        assert!(error.contains("prune_threshold"), "{error}");
    }

    #[test]
    #[ignore = "builds full EHS2 tables over every canonical board; CI runs it in release with --include-ignored"]
    fn ehs2_table_backend_builds_a_session_and_caches_its_tables() {
        let raw = crate::test_fixtures::LOWERED_3MAX;
        let directory = tempfile::tempdir().unwrap();
        let cache_path = directory.path().join("ehs2.postcard");

        // Splice `kind = "ehs2-table"` and `artifact_cache` into
        // `[game.abstraction]` right after the existing `seed` key, mirroring
        let literal = format!("{:?}", cache_path.display().to_string());
        let config_with_kind = raw.replacen(
            "seed = 17\n",
            &format!("seed = 17\nkind = \"ehs2-table\"\nartifact_cache = {literal}\n"),
            1,
        );
        assert_ne!(
            config_with_kind, raw,
            "kind/artifact_cache injection must have matched"
        );

        let session = build_multiway_session(&config_with_kind, None)
            .expect("the ehs2-table backend must build a session");
        assert_eq!(session.sweeps_target, 2);
        assert!(
            cache_path.is_file(),
            "the ehs2 bucket-table cache must be written at build time"
        );
    }
}
