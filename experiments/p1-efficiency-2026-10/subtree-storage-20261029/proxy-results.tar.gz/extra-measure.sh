#!/usr/bin/env bash
set -euo pipefail
D=/work/FreezeCoreProfileResults
SRC=/work/FreezeCoreProfile/experiments/p1-efficiency-2026-10/subtree-storage-20261029/frequency.toml
/work/target-ProfileFinal/release/solvers relock "$D/base" --add "$SRC" --freeze-upstream --print-config > "$D/frozen_frequency.toml"
python3 - "$D" <<'PY'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); freq=p/'frozen_frequency.toml'; text=freq.read_text(); section=re.search(r'(?ms)^\[solver\.stop\]\s*\n.*?(?=^\[|\Z)',text); assert section
body=re.sub(r'(?m)^target\s*=.*\n','',section.group()); body,n=re.subn(r'(?m)^max_iterations\s*=.*$','max_iterations = 50',body); assert n==1; freq.write_text(text[:section.start()]+body+text[section.end():])
text=(p/'frozen_deep.toml').read_text(); section=re.search(r'(?ms)^\[solver\.stop\]\s*\n.*?(?=^\[|\Z)',text); assert section
body,n=re.subn(r'(?m)^target\s*=.*$','target = "0.000000000001bb"',section.group()); body,m=re.subn(r'(?m)^max_iterations\s*=.*$','max_iterations = 2',body); assert n==m==1; (p/'frozen_fallback.toml').write_text(text[:section.start()]+body+text[section.end():])
PY
sha256sum "$D"/frozen_{frequency,fallback}.toml >> "$D/proxy-hashes.txt"
for case in frequency fallback; do for variant in Baseline Final; do label=proxy-$case-$variant; bin=/work/target-Profile$variant/release/solvers; printf '%s\n' "/usr/bin/time -v -o $D/$label.time $bin solve $D/frozen_$case.toml --out $D/$label --threads 32" >> "$D/commands.txt"; /usr/bin/time -v -o "$D/$label.time" "$bin" solve "$D/frozen_$case.toml" --out "$D/$label" --threads 32 > "$D/$label.log" 2>&1; done; done
